  /* ---------- wizard ---------- */
  openWizard(type){ this.setState({screen:'wizard',panel:null,wiz:{type,step:1,kind:null,label:'',api:'',plural:'',desc:'',owner:'@crm/coverage-platform',managedBy:'crm',writerOps:{api:['read','create','update','delete'],job:['read'],ui:[]},container:'core',conv:{audit:true,soft_delete:true,history:false}}}); }
  wizUpd(patch){ this.setState(s=>({wiz:Object.assign({},s.wiz,patch)})); }
  snake(s){ return s.toLowerCase().trim().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''); }
