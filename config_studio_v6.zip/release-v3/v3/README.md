# CRM Config Studio V3

The complete V2 application, organised as source folders. `node build.mjs` concatenates them into the single runnable file `../CRM Config Studio V3.dc.html` (open it next to `support.js`), which behaves exactly like V2.

```
v3/
  build.mjs                    assemble src/ → ../CRM Config Studio V3.dc.html
  src/
    00-head.html               doctype, head, thumbnail, <x-dc>
    template/                  one file per screen / shell part, in build order
      00-root-open.html        helmet: fonts, tokens (all colours live here), body resets
      01-portal-header.html    utility bar, brand, search, Changes, top navigation
      02-section-sub-nav.html  left sub-nav per section
      03-main.html             banners, breadcrumb, main open
      04-home.html … 26-…      one file per screen (Objects, Object detail, Wizard, Picklists, Edges, Views,
                               Consumers, Consumer detail, Register, Changes, Graph queries, Lineage,
                               Conventions, Taxonomy, Audit, Settings, Access, Containers, Releases, Usage)
      27-right-rail.html       YAML / usage rail
      28-… panels & modals     add-field panel, deprecate / remove modals, edit drawer, PAT modal, ⌘K, toast
    50-dc-script-open.html     </x-dc> + the logic <script> tag with the Tweaks props
    logic/                     the Component class, split by concern (concatenated in order)
      00-class-open.js         constructor + initial state (connection defaults live here: state.conn)
      01-static-data.js        get D(): OBJECTS, PLATFORM, CONVENTIONS, CONSUMERS, EDGES, PICKLISTS, VIEWS, GRAPH, ROLES, RELEASES
      02-entity-edit-remove.js 03-settings-connections.js 04-derived.js 05-yaml.js 06-changes.js
      07-add-field.js 08-deprecate.js 09-register-consumer.js 10-wizard.js
      11-render.js             renderVals() head: shell, nav model, breadcrumbs
      12-render-screen-1.js …  renderVals() per screen (Objects, Object detail, Wizard, Picklists, Edges, Consumers,
                               Consumer detail, Register, Changes, Access, Containers, Usage, Graph queries, Right rail,
                               Add field panel, Lineage, Conventions, Taxonomy, Audit, Settings …) and the class close
    99-tail.html               </script> and document end
```

## Authentication

`src/logic/00-0-auth-config.js` is the only file to touch. Prototype: `AUTH.mode = 'local'`, account `admin / admin`. For single sign-on set `AUTH.mode = 'msal'`, fill `clientId / tenantId / authority / scopes`, and implement the three functions `signIn`, `acquireToken`, `signOut` with `@azure/msal-browser` (loginRedirect, acquireTokenSilent, logoutRedirect). `fromClaims` maps ID-token claims to the studio user (name, upn, oid, roles, team). The login screen, user chip, sign-out and the PAT flow pick it up automatically.

## Brand colours

The prototype ships with a neutral placeholder palette (teal primary, warm highlight). To apply your brand:

1. Open `src/template/00-root-open.html`. At the top of each `[data-theme="light"]` / `[data-theme="dark"]` block are the six **BRAND TOKENS**:
   - `--ac` primary (buttons, links, focus node, brand tile)
   - `--acfg` text on primary
   - `--actx` primary used as text on light surfaces (must pass 4.5:1 on `--sf`)
   - `--acbg` primary tint (selected rows, chips, glyph tiles)
   - `--hero` home hero background
   - `--ac2` / `--ac2fg` secondary highlight (active nav underline, nav hover, Changes badge)
2. Replace the values; hex or oklch both work. Keep the dark-theme set lighter/less saturated.
3. Optionally change the font in the same file (`html,body{font-family:…}` and the Google Fonts link) and the brand tile text `CS` in `src/template/01-portal-header.html`.
4. `node build.mjs` and reload.

Nothing else in the codebase holds a raw colour, so this is the whole job. Status/category hues (`--gr`, `--am`, `--rd`, `--pu`, `--bl`) are semantic, not brand, and can stay.

## Field exposure and graph queries

- Every field has `exposure: {ui, api}` (`edit | view | hidden`): a channel ceiling independent of roles and grants. Set it in the Add/Edit field panel; it shows as UI/API chips on the Fields tab and blocks consumer grants that exceed it. Sample values live in `src/logic/01-static-data.js` (`EXPO`).
- Graph queries are editable by every Design-mode user: New / Edit / Deprecate on the Graph queries screen (`src/logic/02-entity-edit-remove.js` → `openNewGraph`, `saveNewGraph`; edit spec `kind==='graph'`).

## Where to put your own data

| What | File |
| --- | --- |
| Objects, fields, edges, picklists, views, graph queries, releases | `src/logic/01-static-data.js` (`get D()`) — replace the literals or fetch from the middleware and assign `this._D` |
| Connection defaults per environment (Azure Repos, Cosmos accounts, Monitor, Functions, Key Vault, SQL, party master) | `src/logic/00-class-open.js` → `state.conn` and `static ENVS / DEPLOYED` |
| Environments and deployed releases | `src/logic/00-class-open.js` → `static ENVS`, `ENV_FULL`, `DEPLOYED` |
| Signed-in user, PAT status, audit seed | `src/logic/00-class-open.js` → `state.user`, `state.pat`, `static AUDIT_SEED` |
| Brand colours | `src/template/00-root-open.html` → the six BRAND TOKENS per theme (`--ac`, `--acfg`, `--actx`, `--acbg`, `--hero`, `--ac2`); fonts in the same file |

Wiring to the FastAPI middleware: every `pushChange(...)`, `saveEdit()`, `saveField()`, `saveConsumer()`, `testConn()` in `src/logic/` is the place to call the matching endpoint from `../middleware/README.md`; the UI already models the response (change list, toasts, status chips).

After editing: `node build.mjs`, then reload `CRM Config Studio V3.dc.html`.
