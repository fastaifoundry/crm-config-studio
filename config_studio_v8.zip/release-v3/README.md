# CRM Config Studio

Design-and-catalog studio for a Cosmos DB-backed CRM configuration system: objects, fields, edges, picklists, views, consumers (FastAPI on Azure Functions), graph queries, containers, taxonomy, lineage, audit.

## What is here

| Path | What it is |
| --- | --- |
| `CRM Config Studio v1.1.dc.html` + `support.js` | The interactive UI prototype (all screens, Design/Catalog, Dev/Test/Acc/Prod, sample data). Open in a browser from this folder. |
| `export/CRM Config Studio v1.1 standalone.html` | Same UI bundled into one self-contained file, no external loads. Share this one. |
| `CRM Config Studio V2.dc.html` + `export/CRM Config Studio V2 standalone.html` | **V2** — portal-style re-skin (top nav + section sub-nav, card catalogs, Home, Conventions page, re-imagined Lineage). Same logic and middleware contract as v1.1. |
| `CRM Config Studio.dc.html` | v1 (pre party-model), kept for reference. |
| `CRM Config Studio V3.dc.html` + `v3/` | **V3** — the complete V2 app, organised as source folders (`v3/src/template/` one file per screen, `v3/src/logic/` one file per concern, data in `01-static-data.js`, connections in `00-class-open.js`). `node v3/build.mjs` assembles the runnable file. See `v3/README.md`. |
| `middleware/` | FastAPI backend-for-frontend (Python 3.12). Azure Repos · Azure Pipelines · Cosmos DB · Azure Monitor · Azure Functions · Key Vault · Azure SQL (SQLAlchemy + Alembic) · party master. See `middleware/README.md`. |
| `scripts/collect-containers.sh` | az CLI collector for the Containers screen (config, throughput, RU, size, documents by `_type`, top partitions) across tagged Cosmos accounts. |

## V3 highlights

In-app guide: **How it works** (top nav) — lane chart of branch → PR → main → pipeline → per-environment deployments, step by step, and the rules the studio enforces.

Login screen (prototype `admin` / `admin`; MSAL provision in `v3/src/logic/00-0-auth-config.js`), portal layout, Conventions page (platform fields defined once), per-field UI/API exposure, editable graph queries, lineage with resizable panels, per-user PAT commits and audit. Brand colours: six tokens, see `v3/README.md`.

## V3 package

For the V3 hand-over take: `CRM Config Studio V3.dc.html` + `support.js` (runnable UI), `export/CRM Config Studio V3 standalone.html` (share-able single file), `v3/` (UI source + build), `middleware/` (FastAPI, incl. `schema-examples/` for the repo layout), `scripts/`, this README.

## Model in one paragraph

Git (Azure Repos) is the only store for configuration; every Design-mode save is a commit on `studio/<user>/<date>` made with the user's own PAT, promoted by pull request in Azure DevOps. One middleware and one Azure SQL per environment; SQL holds what the pipeline deployed there (`cfg_*`) plus audit, sessions, connection results and usage snapshots (`ops_*`). Production is catalog only. Consumers are FastAPI function apps discovered by tag, each with its own managed identity; Cosmos accounts are discovered by tag and read with one shared managed identity.

## Brand colours

V3: six BRAND TOKENS at the top of `v3/src/template/00-root-open.html`, step-by-step in `v3/README.md` → *Brand colours*. V2: same tokens inline at the top of `CRM Config Studio V2.dc.html`.

## Design tokens (V2)

All colour lives in the `[data-theme]` blocks at the top of `CRM Config Studio V2.dc.html`: `--ac/--acbg/--actx` (accent), `--bl` (consumers), `--gr` (views), `--am` (edges), `--pu` (picklists), `--rd` (graph queries), neutrals `--bg/--sf/--bd/--tx`. Swap these for brand tokens; nothing else references raw colours.

## Next steps to make it real

1. Vue port of the UI against `middleware/README.md` endpoint table (MSAL sign-in, `X-Studio-Env` per deployment).
2. Fill `middleware/.env.example`, run `alembic upgrade head`, `uvicorn app.main:app`.
3. Wire the schema pipeline: lint → breaking-change scan → deploy → `python -m app.deploy.sync_to_sql`; schedule `collect_usage` (15m / 1h / 1d).
