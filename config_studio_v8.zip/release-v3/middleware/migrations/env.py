"""Alembic environment. Uses the same Settings/token auth as the app; autogenerate compares against app.db.models.Base.

  alembic revision --autogenerate -m "init"
  alembic upgrade head
"""
from __future__ import annotations

import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config

from app.db.models import Base
from app.db.session import odbc_string
from app.settings import get_settings

config = context.config
if config.config_file_name:
    fileConfig(config.config_file_name)
target_metadata = Base.metadata

import urllib.parse
config.set_main_option("sqlalchemy.url", "mssql+aioodbc:///?odbc_connect=" + urllib.parse.quote_plus(odbc_string(get_settings())))


def run_migrations_offline() -> None:
    context.configure(url=config.get_main_option("sqlalchemy.url"), target_metadata=target_metadata, literal_binds=True, dialect_opts={"paramstyle": "named"})
    with context.begin_transaction():
        context.run_migrations()


def _run(connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata, compare_type=True)
    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    from app.db.session import Database
    db = Database(get_settings())  # token-injecting engine
    async with db.engine.connect() as connection:
        await connection.run_sync(_run)
    await db.engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
