"""Azure Functions (Python v2) entry point. Deploy with `func azure functionapp publish <app>`.

host.json needs:  { "version": "2.0", "extensions": { "http": { "routePrefix": "" } } }
so FastAPI owns the full path (/api/objects, /docs, /health).
"""
import azure.functions as func

from app.main import app as fastapi_app

app = func.AsgiFunctionApp(app=fastapi_app, http_auth_level=func.AuthLevel.ANONYMOUS)  # auth is the Entra bearer token, checked in app.auth
