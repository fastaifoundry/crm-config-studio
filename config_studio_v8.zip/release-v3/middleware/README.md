# CRM Config Studio — middleware (FastAPI)

Backend-for-frontend between the Vue UI (static, Azure Storage + CDN) and the real systems. The UI only ever talks to this service; the service holds one managed identity and talks to Azure Repos, Cosmos DB, Azure Monitor, Azure Functions, Key Vault, Azure SQL and the party master.

**Git is the only store for configuration.** The middleware reads YAML from Azure Repos on every request (short TTL cache) and writes every change as a commit on a per-user branch. There is no second copy to reconcile, so no service hooks are needed: edit the repo directly and the UI shows it on the next load.

```
Vue (Azure Storage)  ──HTTPS + Entra token──▶  FastAPI middleware (Azure Functions or Container Apps)
                                                  ├─ Azure Repos       objects/edges/picklists/views/consumers/graph YAML · branch · push · PR · tags
                                                  ├─ Azure Pipelines   lint / breaking-change / deploy run status per branch
                                                  ├─ Cosmos DB (MI)    containers, indexing policy, throughput, documents by _type — every tagged account
                                                  ├─ Azure Monitor     RU per identity/object/container, sizes, partition stats (Log Analytics)
                                                  ├─ Azure Functions   tagged function apps → consumers, managed identities, App Insights routes
                                                  ├─ Key Vault         GitHub token, party-master cert
                                                  ├─ Party master      field definitions for party / person / organisation
                                                  └─ Azure SQL         the middleware's own records only: audit, change sessions, connection results, catalog snapshots
```

## Layout

```
middleware/
  pyproject.toml
  app/
    main.py            app factory, CORS, routers, error mapping
    settings.py        pydantic-settings; mirrors the Settings screen (env vars or Key Vault)
    auth.py            Entra ID (MSAL) bearer-token validation, roles, team code; require_design also enforces prod = catalog only
    identity.py        per-user Azure Repos PAT (Key Vault), user-scoped YamlRepo for writes, audit() helper
    env.py             environment enum + writable-env guard
    deploy/sync_to_sql.py  pipeline step: YAML at deployed ref → cfg_* + ops_deployment
    models.py          pydantic models shared by routers (the UI's JSON shapes)
    yamlrepo.py        read/write the schema repo through the Azure Repos client; session branches; diff
    db/
      models.py        SQLAlchemy 2.0 ORM: cfg_* (deployed config, pipeline-written) + ops_* (deployments, audit, sessions, connections, snapshots)
      session.py       async engine (managed-identity token auth) + session factory
      repo.py          OpsRepo: audit, sessions, connection results, snapshots
  migrations/          Alembic (env.py wired to the same settings/auth); alembic.ini at the root
    clients/
      azure_repos.py   Azure Repos Git REST: items, refs, pushes, pull requests, tags; Azure Pipelines runs
      cosmos.py        control plane (list accounts by tag, containers, policy, throughput) + data plane (GROUP BY _type)
      monitor.py       Azure Monitor metrics + Log Analytics KQL
      functions.py     function apps by tag, identities, App Insights requests
      keyvault.py      secrets
      party_master.py  schema pull
    routers/               (conventions.py = platform fields defined once per convention)
    routers/
      schema.py        /api/objects /api/edges /api/picklists /api/views /api/graph-queries  (Design: working branch · Catalog: release tag)
      consumers.py     /api/consumers  register / update grants / revoke, routes
      changes.py       /api/changes  diff, lint, breaking, open PR
      catalog.py       /api/catalog/containers /usage /releases
      connections.py   /api/connections  list / test  (what the Settings screen calls)
      access.py        /api/access  roles, team tree, sweeps
      lineage.py       /api/lineage/{object|consumer}/{id}?cadence=  upstream/downstream graph + who·what·when·how·why + usage
      me.py            /api/me
```

## Run locally

```bash
cd middleware
python -m venv .venv && . .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env            # fill in ADO_ORG/PROJECT/REPO, COSMOS_TAG, … or point KEYVAULT_URL at a vault
az login                        # DefaultAzureCredential picks it up; in Azure the managed identity does
uvicorn app.main:app --reload --port 8000
# OpenAPI: http://localhost:8000/docs
```

## Deploy

Azure Functions (Python v2 model, ASGI) is the default so the middleware is hosted the same way as the consumers it governs:

```bash
func init --python --model V2         # once; function_app.py wraps app.main:app with AsgiFunctionApp
func azure functionapp publish func-crm-config-studio-prod
```

Container Apps works unchanged (`uvicorn app.main:app --host 0.0.0.0 --port 8000`).

## Environments

One middleware deployment and one Azure SQL database per environment (`ENVIRONMENT=dev|test|acc|prod`); each points at that environment's Cosmos accounts, function apps and App Insights by tag. Azure Repos, Azure Pipelines, Entra and Key Vault are shared.

| env | Design | Catalog reads | deployed from |
| --- | --- | --- | --- |
| dev | yes | Azure SQL dev | any studio branch or main (pipeline on push) |
| test / acc | yes | Azure SQL test / acc | tagged release |
| prod | **no** — every write route returns 403 | Azure SQL prod | main only, on merged PR |

After each deploy the pipeline runs `python -m app.deploy.sync_to_sql --ref <ref> --commit <sha>`, which replaces the `cfg_*` rows with the YAML at that ref and appends an `ops_deployment` row. That is how SQL always reflects *what runs here*; no service hooks are involved. `GET /api/catalog/deployment` reports deployed ref vs main.

## Identity and audit

- **Sign-in**: MSAL in the Vue app (auth code + PKCE) against the studio's Entra app registration; the API validates the bearer token (`auth.py`) and derives roles and team code from claims.
- **Writes carry the user's name**: every commit, branch and pull request is made with the *caller's* Azure Repos PAT, fetched per request from Key Vault (`ado-pat-<oid>`, set via `PUT /api/me/pat`, verified against the repo before storing). The managed identity is read-only. Without a PAT, write routes return 428.
- **Audit**: every mutating route writes an `ops_audit` row (upn, action, target, branch, commit id, environment). `GET /api/audit?q=&mine=` merges it with `ops_deployment`; PR approvals and completions are visible in Azure DevOps history under the same user.

## Usage cadences

The Lineage and Usage screens take `cadence` = `15m`, `1h`, `1d` and read `ops_catalog_snapshot` rows (`usage_15m`, `usage_1h`, `usage_1d`) written by the collector job on that schedule, so views cost nothing per request. `refresh=true` pulls Log Analytics on demand (rate-limited to one per user per 2 minutes), stores the result as the newest snapshot and audits who asked. Every response states its `as_of`.

## Change flow

1. First design-mode save creates `studio/<user>/<yyyymmdd>` from `main` and commits the YAML there. Every later save is another commit on that branch.
2. **Changes** = `main...branch` diff + lint + breaking-change scan + the schema pipeline's result on the branch.
3. **Submit** opens the pull request in Azure DevOps with object owners as reviewers. Approval and completion happen in Azure DevOps; the middleware never writes to `main`.
4. On merge the schema pipeline tags the release, applies `storage/*.yaml` index changes to Cosmos DB and starts view rebuilds. Catalog mode reads the latest tag.

## Azure SQL

Per environment. `cfg_*` = configuration as deployed to this environment (written only by the pipeline step above; Catalog reads it). `ops_deployment`, `ops_audit`, `ops_change_session`, `ops_connection`, `ops_catalog_snapshot` = the middleware's own records. Design mode never reads SQL; it reads git.

ORM: SQLAlchemy 2.0 (async, `aioodbc`) + Alembic. Same managed identity as everything else; grant `db_datareader`, `db_datawriter`, `db_ddladmin`.

```bash
alembic revision --autogenerate -m "init"
alembic upgrade head
```

## Environment parameters

One middleware and one Azure SQL per environment, so everything in that database is environment-scoped by construction. Two tables carry settings: `ops_connection.config` (non-secret connection values saved from the Settings screen; `PUT /api/connections/{id}`; secrets stay Key Vault names) and `ops_setting` (operational parameters: lineage cadence, refresh gap, RU warning %, default sunset, PR reviewers, usage window, purge retention; `GET/PUT /api/settings`). `effective_settings()` = environment defaults overlaid with stored values; lineage, catalog and deprecation forms read it. Changing a parameter needs no release and never touches the schema repo.

## Metadata in grants

A consumer grant may list platform (metadata) attributes — `id`, `party_id`, `team_id`, `created_at`, `updated_at`, `version`, … — alongside object fields. They are projected into responses and allowed in named-query filters/sorts, and are read-only on every channel regardless of the grant's access. The Register screen offers **+ core metadata** (`id, party_id, updated_at, version`) and **+ all metadata**.

## Field exposure

Every field carries `exposure: {ui, api}` with values `edit | view | hidden` — channel-level control independent of roles (RLS) and consumer grants. The runtime applies it as a ceiling: a UI consumer never gets more than `exposure.ui` on that field, an API consumer never more than `exposure.api`, whatever the grant says. `POST /consumers` rejects rw grants that exceed it unless the field is listed in the grant's `read_only`. Persisted with the rest of the field inside the deployed `cfg_object.doc` JSON; the runtime reads it from there.

## Graph queries

Any Design-mode user may register or edit a graph query (`PUT /api/graph-queries/{name}`, `POST …/deprecate`); it lands on their branch like everything else and goes through the same pull request. The pipeline runs the traversal once against test data and fails the release if it exceeds the latency target.

## Conventions

- **Mode is a query parameter**: `?mode=design` reads the caller's session branch (falls back to `main` until the first write); `?mode=catalog` reads the latest release tag. Writes are only accepted in design mode.
- **Every write is a commit on the session branch**, never to `main`. `POST /api/changes/pr` opens the pull request; approval and merge happen in Azure DevOps.
- **Read-only against Azure.** The identity holds *Cosmos DB Built-in Data Reader*, *Monitoring Reader*, *Reader* on function apps, *Key Vault Secrets User*. Nothing here can mutate Cosmos DB.
- **Discovery by tag.** Cosmos accounts (`COSMOS_TAG`), function apps (`FUNCTIONS_TAG`). New resources appear without config changes.
- **Caching.** Repo tree and Azure snapshots are cached in-process for `CACHE_TTL_SECONDS` (default 60; catalog metrics 900). `X-Studio-Refresh: 1` bypasses.
- **Errors** map to `{ "error": { "code", "message", "detail" } }`; upstream failures return 502 with the upstream body summarised.

## Endpoint summary

| Method | Path | Screen |
| --- | --- | --- |
| GET | /api/me · PUT/DELETE /api/me/pat · GET /api/audit | shell, user menu, Audit |
| GET · POST/PATCH/DELETE …/{conv}/fields[/{name}] · POST …/deprecate | /api/conventions | Conventions (platform fields): reads/writes `conventions/<id>.yaml`, resolves affected objects by kind + conventions list |
| GET | /api/objects · /api/objects/{api} | Object catalog, Object detail |
| POST · PATCH · DELETE | /api/objects[/{api}] | wizard, Edit, Retire |
| POST · PATCH · POST …/deprecate | /api/objects/{api}/fields[/{name}] | Add/edit field, Deprecate field |
| GET · PATCH · DELETE | /api/edges[/{name}] | Edge detail |
| GET · PATCH · DELETE · POST …/values · POST …/values/{v}/deprecate | /api/picklists[/{name}] | Picklists |
| GET · POST · PATCH · DELETE | /api/views[/{name}] | Views |
| GET | /api/graph-queries[/{name}] | Graph queries |
| GET · POST · PATCH · DELETE | /api/consumers[/{name}] | Consumer catalog, Register, Edit grants, Revoke |
| GET | /api/consumers/{name}/usage · /routes | Consumer detail tabs |
| GET | /api/changes · POST /api/changes/pr · DELETE /api/changes | Change preview |
| GET | /api/catalog/containers · /usage · /releases · /deployment | Containers, Usage, Releases, env banner |
| GET | /api/access | Access model |
| GET | /api/lineage/{kind}/{id}?cadence=15m·1h·1d&field=&refresh= | Lineage |
| GET · POST …/{id}/test | /api/connections | Settings |
