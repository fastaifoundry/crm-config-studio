"""The schema repository (Azure Repos) as objects. Reads YAML from a ref, writes YAML to the caller's session branch, computes diffs.

Git is the only store for configuration. Reads go to the repo on every request (TTL cache); there is no copy to reconcile.

Layout in the repo (GITHUB_SCHEMA_PATH):
  objects/<api>.yaml  edges/<name>.yaml  picklists/<name>.yaml  views/<name>.yaml
  consumers/<type>/<name>.yaml  graph/<name>.yaml  storage/<container>.yaml
"""
from __future__ import annotations

import asyncio
from datetime import UTC, date, datetime, timedelta

import yaml
from cachetools import TTLCache
from fastapi import HTTPException

from .auth import User
from .clients.azure_repos import AzureRepos
from .models import BreakingItem, ChangedFile, ChangeSet, ConsumerDef, Deprecation, LintItem, Mode, ObjectDef

KINDS = {"objects": "objects", "edges": "edges", "picklists": "picklists", "views": "views", "graph": "graph", "storage": "storage"}


class YamlRepo:
    def __init__(self, git: AzureRepos, base_branch: str, prefix: str, ttl: int, prod_readonly: bool = False):
        self.git, self.base, self.prefix, self.prod_readonly = git, base_branch, prefix.strip("/") + "/", prod_readonly
        self.cache: TTLCache = TTLCache(maxsize=64, ttl=ttl)

    # ---- refs ----
    async def ref_for(self, mode: Mode, user: User, deployed_ref: str | None = None) -> str:
        """catalog → the ref the pipeline deployed to this environment (from ops_deployment), else latest tag;
        design → the caller's studio branch if it exists, else main. In prod design always resolves to main."""
        if mode == Mode.catalog:
            return deployed_ref or await self.git.latest_release_tag() or self.base
        if self.prod_readonly:
            return self.base
        return (await self.git.branch_sha(user.session_branch)) and user.session_branch or self.base

    # ---- read ----
    async def list(self, kind: str, ref: str, refresh: bool = False) -> list[dict]:
        key = (kind, ref)
        if not refresh and key in self.cache:
            return self.cache[key]
        blobs = await self.git.tree(ref, f"{self.prefix}{KINDS[kind]}/")
        texts = await asyncio.gather(*(self.git.read(b["path"], ref) for b in blobs))
        docs = []
        for b, t in zip(blobs, texts):
            if t:
                d = yaml.safe_load(t[0]) or {}
                d["_path"] = b["path"].removeprefix(self.prefix)
                docs.append(d)
        self.cache[key] = docs
        return docs

    async def get(self, kind: str, name: str, ref: str, sub: str = "") -> dict | None:
        r = await self.git.read(self._path(kind, name, sub), ref)
        return (yaml.safe_load(r[0]) or {}) if r else None

    async def consumers(self, ref: str) -> list[dict]:
        blobs = await self.git.tree(ref, f"{self.prefix}consumers/")
        texts = await asyncio.gather(*(self.git.read(b["path"], ref) for b in blobs))
        return [yaml.safe_load(t[0]) | {"_path": b["path"].removeprefix(self.prefix)} for b, t in zip(blobs, texts) if t]

    # ---- write (design mode only) ----
    def _path(self, kind: str, name: str, sub: str = "") -> str:
        folder = "consumers" if kind == "consumers" else KINDS[kind]
        return f"{self.prefix}{folder}/{sub + '/' if sub else ''}{name}.yaml"

    async def put(self, kind: str, name: str, doc: dict, user: User, message: str, sub: str = "") -> str | None:
        """Commit on the user's branch with the user's PAT (author = user). Returns the new commit id."""
        await self.git.ensure_branch(user.session_branch, self.base)
        text = yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=120)
        await self.git.write(self._path(kind, name, sub), text, f"{message}\n\nvia CRM Config Studio", user.session_branch)
        self.cache.clear()
        return await self.git.branch_sha(user.session_branch)

    async def remove(self, kind: str, name: str, user: User, message: str, sub: str = "") -> str | None:
        await self.git.ensure_branch(user.session_branch, self.base)
        await self.git.delete(self._path(kind, name, sub), f"{message}\n\nvia CRM Config Studio", user.session_branch)
        self.cache.clear()
        return await self.git.branch_sha(user.session_branch)

    # ---- rules shared by routers ----
    @staticmethod
    def check_deprecation(dep: Deprecation) -> None:
        try:
            sunset = date.fromisoformat(dep.sunset)
        except ValueError as e:
            raise HTTPException(422, "sunset must be an ISO date") from e
        if sunset < date.today() + timedelta(days=90):
            raise HTTPException(422, "sunset must be at least 90 days out")

    @staticmethod
    def dependants(kind: str, target: str, consumers: list[dict], field: str | None = None) -> list[str]:
        out = []
        for c in consumers:
            for g in c.get("grants", []):
                if g.get(kind) != target and not (kind == "object" and g.get("object") == target):
                    continue
                if field and g.get("fields") != "*" and field not in (g.get("fields") or []):
                    continue
                out.append(c["name"])
                break
        return out

    # ---- change preview ----
    async def changeset(self, user: User, objects: list[dict], consumers: list[dict]) -> ChangeSet:
        head = user.session_branch
        if not await self.git.branch_sha(head):
            return ChangeSet(branch=head, base=self.base, files=[], lint=[], breaking=[], reviewers=[])
        cmp = await self.git.compare(self.base, head)
        files = [ChangedFile(path=f["filename"].removeprefix(self.prefix), status={"added": "A", "modified": "M", "removed": "D", "renamed": "M"}[f["status"]],
                             additions=f["additions"], deletions=f["deletions"], patch=f.get("patch", "")) for f in cmp["files"]]
        lint, breaking = self._lint(files, objects, consumers)
        owners = {o["owner"] for o in objects if any(f.path == f"objects/{o['api_name']}.yaml" for f in files)}
        # Azure Pipelines result, if the schema pipeline already ran on the branch
        for run in await self.git.check_runs(head):
            if run["conclusion"] in ("failure", "action_required"):
                lint.append(LintItem(severity="error", location=run["name"], message=run.get("output", {}).get("title") or "check failed"))
        return ChangeSet(branch=head, base=self.base, files=files, lint=lint, breaking=breaking, reviewers=sorted(owners | {"@crm/schema-reviewers"}))

    def _lint(self, files: list[ChangedFile], objects: list[dict], consumers: list[dict]) -> tuple[list[LintItem], list[BreakingItem]]:
        lint: list[LintItem] = []
        breaking: list[BreakingItem] = []
        for f in files:
            if f.status == "D":
                kind, name = f.path.split("/")[0].rstrip("s"), f.path.split("/")[-1].removesuffix(".yaml")
                deps = self.dependants(kind, name, consumers)
                if deps:
                    breaking.append(BreakingItem(kind="delete", message=f"{kind} {name} deleted while in use", affects=deps))
            if "+    status: deprecated" in f.patch:
                lint.append(LintItem(severity="info", location=f.path, message="Deprecation: dependants are routed for review; blocked only if sunset < 90 days."))
            if "+  filterable: true" in f.patch or "+    filterable: true" in f.patch:
                lint.append(LintItem(severity="info", location=f.path, message="New indexed path. Online rebuild ≈ 4 min per 1M documents."))
            if f.path.startswith("consumers/") and 'fields: "*"' in f.patch:
                lint.append(LintItem(severity="warn", location=f.path, message="Wildcard field grant. Architect approval required."))
        return lint, breaking

    async def open_pr(self, user: User, cs: ChangeSet, title: str) -> str:
        body = "\n".join(["Opened from CRM Config Studio.", "", "### Files", *(f"- `{f.path}` ({f.status})" for f in cs.files), "",
                          "### Breaking", *(f"- {b.message} → {', '.join(b.affects)}" for b in cs.breaking)] or ["none"])
        pr = await self.git.open_pr(cs.branch, self.base, title, body, cs.reviewers)
        return pr["html_url"]

    async def discard(self, user: User) -> None:
        await self.git.delete_branch(user.session_branch)
        self.cache.clear()

    @staticmethod
    def now() -> str:
        return datetime.now(UTC).isoformat(timespec="seconds")
