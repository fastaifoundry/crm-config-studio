"""Entra ID bearer-token validation. The Vue app signs users in with MSAL (authorization code + PKCE) and sends the
access token for this API's app registration; every /api route depends on `current_user`. Identity for writes to Azure
Repos is separate: each user's own PAT (see identity.py), so git history and the audit log name the same person."""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache

import httpx
import jwt
from fastapi import Depends, HTTPException, Request, status
from jwt import PyJWKClient

from .settings import Settings, get_settings

ROLE_ORDER = ["assistant", "rm", "senior_rm", "team_lead", "compliance", "admin"]


@dataclass
class User:
    upn: str
    oid: str
    name: str
    roles: list[str] = field(default_factory=list)
    groups: list[str] = field(default_factory=list)
    team_code: str | None = None

    @property
    def can_design(self) -> bool:
        # Design mode (writes to the repo) is for schema owners and admins; everyone signed in may read the Catalog.
        return bool({"schema_owner", "architect", "admin"} & set(self.roles))

    @property
    def is_architect(self) -> bool:
        return bool({"architect", "admin"} & set(self.roles))

    @property
    def session_branch(self) -> str:
        from datetime import UTC, datetime

        safe = self.upn.split("@")[0].replace(".", "-").lower()
        return f"studio/{safe}/{datetime.now(UTC):%Y%m%d}"


@lru_cache
def _jwks(tenant: str) -> PyJWKClient:
    meta = httpx.get(f"https://login.microsoftonline.com/{tenant}/v2.0/.well-known/openid-configuration", timeout=10).json()
    return PyJWKClient(meta["jwks_uri"], cache_keys=True)


def current_user(request: Request, s: Settings = Depends(get_settings)) -> User:
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "missing bearer token")
    token = auth[7:]
    try:
        key = _jwks(s.entra_tenant_id).get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token, key, algorithms=["RS256"], audience=s.entra_audience,
            issuer=f"https://login.microsoftonline.com/{s.entra_tenant_id}/v2.0",
        )
    except jwt.PyJWTError as e:  # expired, wrong audience, bad signature
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, f"invalid token: {e}") from e
    return User(
        upn=claims.get("preferred_username") or claims.get("upn", ""),
        oid=claims["oid"],
        name=claims.get("name", ""),
        roles=list(claims.get("roles", [])),
        groups=list(claims.get(s.entra_groups_claim, [])),
        team_code=claims.get(s.entra_team_attr),
    )


def require_design(user: User = Depends(current_user), s: Settings = Depends(get_settings)) -> User:
    if s.environment == "prod":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "production is catalog only; design in dev, test or acceptance and promote through a pull request")
    if not user.can_design:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "design mode requires the schema_owner or architect role")
    return user


def require_architect(user: User = Depends(current_user)) -> User:
    if not user.is_architect:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "architect role required")
    return user
