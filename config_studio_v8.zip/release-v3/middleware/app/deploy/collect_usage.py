"""Scheduled collector: writes usage rollups the Lineage/Usage screens read for the 15m / 1h / 1d cadences.

Run from the pipeline's scheduled job or a timer-triggered function:
  python -m app.deploy.collect_usage --cadence 15m     (every 15 min)
  python -m app.deploy.collect_usage --cadence 1h      (hourly)
  python -m app.deploy.collect_usage --cadence 1d      (03:00 nightly)
"""
from __future__ import annotations

import argparse
import asyncio

from ..db.repo import OpsRepo
from ..db.session import Database
from ..deps import Services
from ..settings import get_settings

WINDOW = {"15m": 1, "1h": 1, "1d": 7}  # days of history to keep in each rollup


async def main(cadence: str) -> None:
    s = get_settings()
    svc = await Services.build(s)
    rows = await svc.monitor.ru_by_identity(days=WINDOW[cadence])
    shapes = await svc.monitor.query_shapes(days=WINDOW[cadence])
    async with svc.db.session() as ses:
        await OpsRepo(ses).snapshot(f"usage_{cadence}", {"rows": rows, "shapes": shapes, "environment": s.environment})
    await svc.aclose()
    print(f"{s.environment}: usage_{cadence} · {len(rows)} identity-days · {len(shapes)} query shapes")


if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--cadence", choices=list(WINDOW), required=True)
    asyncio.run(main(p.parse_args().cadence))
