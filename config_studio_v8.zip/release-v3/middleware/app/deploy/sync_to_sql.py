"""Pipeline step: record what was just deployed to this environment in its Azure SQL.

Run by the schema pipeline after a successful deploy (dev: on every studio-branch build, test/acc: on tagged releases,
prod: on merge to main). Reads the YAML at the deployed ref from Azure Repos and upserts it into cfg_* tables, then
writes one ops_deployment row. Catalog mode reads these tables; "deployed vs main" comes from ops_deployment.commit.

  python -m app.deploy.sync_to_sql --ref 2026.09.07-3 --commit b81c2d0 --pipeline-run 1234
"""
from __future__ import annotations

import argparse
import asyncio
from datetime import UTC, datetime

import yaml

from ..clients.azure_repos import AzureRepos
from ..db.models import CfgConsumer, CfgEdge, CfgGraphQuery, CfgObject, CfgPicklist, CfgView, Deployment
from ..db.session import Database
from ..settings import get_settings


async def main(ref: str, commit: str, run: str | None) -> None:
    s = get_settings()
    from azure.identity.aio import DefaultAzureCredential
    cred = DefaultAzureCredential(managed_identity_client_id=s.managed_identity_client_id) if s.managed_identity_client_id else DefaultAzureCredential()
    git = AzureRepos(s.ado_org, s.ado_project, s.ado_repo, cred=cred)
    db = Database(s)
    prefix = s.ado_schema_path.strip("/") + "/"
    blobs = await git.tree(ref, prefix)
    docs: dict[str, list[dict]] = {}
    for b in blobs:
        rel = b["path"].removeprefix(prefix)
        kind = rel.split("/")[0]
        text = await git.read(b["path"], ref)
        if text:
            docs.setdefault(kind, []).append(yaml.safe_load(text[0]) or {})

    async with db.session() as ses:
        # replace-all per environment: the deployed state is exactly the ref's content
        for model in (CfgConsumer, CfgView, CfgEdge, CfgGraphQuery, CfgObject, CfgPicklist):
            await ses.execute(model.__table__.delete())
        ses.add_all(CfgPicklist(name=d["name"], doc=d) for d in docs.get("picklists", []))
        ses.add_all(CfgObject(api_name=d["api_name"], kind=d["kind"], container=d["container"], owner=d["owner"], status=d.get("status", "active"),
                              managed_by=d.get("managed_by", "crm"), doc=d) for d in docs.get("objects", []))
        ses.add_all(CfgEdge(name=d["name"], doc=d) for d in docs.get("edges", []))
        ses.add_all(CfgView(name=d["name"], object_api=d["object"], doc=d) for d in docs.get("views", []))
        ses.add_all(CfgGraphQuery(name=d["name"], doc=d) for d in docs.get("graph", []))
        ses.add_all(CfgConsumer(name=d["name"], type=d["type"], owner=d["owner"], function_app=d["hosting"]["function_app"],
                                managed_identity_client_id=d["hosting"]["managed_identity_client_id"], doc=d) for d in docs.get("consumers", []))
        ses.add(Deployment(environment=s.environment, ref=ref, commit=commit, pipeline_run=run, deployed_at=datetime.now(UTC),
                           objects=len(docs.get("objects", [])), consumers=len(docs.get("consumers", []))))
    await db.dispose()
    print(f"{s.environment}: deployed {ref}@{commit} · {len(docs.get('objects', []))} objects · {len(docs.get('consumers', []))} consumers")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--ref", required=True, help="branch or tag that was deployed")
    p.add_argument("--commit", required=True)
    p.add_argument("--pipeline-run")
    a = p.parse_args()
    asyncio.run(main(a.ref, a.commit, a.pipeline_run))
