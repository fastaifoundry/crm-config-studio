from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..auth import ROLE_ORDER, User, current_user
from pydantic import BaseModel

from ..db.repo import OpsRepo
from ..deps import Services, services
from ..identity import audit, delete_pat, pat_status, store_pat

router = APIRouter(prefix="/api", tags=["access"])


@router.get("/me")
async def me(user: User = Depends(current_user), svc: Services = Depends(services)):
    env = svc.settings.environment
    async with svc.db.session() as s:
        dep = await OpsRepo(s).latest_deployment()
    return {"upn": user.upn, "name": user.name, "roles": user.roles, "team_code": user.team_code,
            "environment": env, "catalog_only": env == "prod", "can_design": user.can_design and env != "prod", "is_architect": user.is_architect,
            "session_branch": None if env == "prod" else user.session_branch, "pat": await pat_status(user, svc),
            "deployed": {"ref": dep.ref, "commit": dep.commit, "at": dep.deployed_at.isoformat()} if dep else None}


@router.get("/access")
async def access(user: User = Depends(current_user), svc: Services = Depends(services)):
    """Role ladder and the per-field security matrix, derived from the repo; sweeps from Log Analytics if present."""
    objects = await svc.repo.list("objects", svc.repo.base)
    matrix = {o["api_name"]: {f["name"]: {r: ("rw" if r in f.get("security", {}).get("write", []) else "r" if r in f.get("security", {}).get("read", []) else "-")
                                          for r in ROLE_ORDER} for f in o.get("fields", [])} for o in objects}
    sweeps = []
    if svc.monitor.logs:
        from datetime import timedelta
        res = await svc.monitor.logs.query_workspace(svc.monitor.ws, """
            AppTraces | where Message startswith 'reassign_team' | project TimeGenerated, Properties | top 10 by TimeGenerated desc""",
            timespan=timedelta(days=30))
        sweeps = [dict(zip(res.tables[0].columns, r)) for r in res.tables[0].rows] if res.tables else []
    return {"roles": ROLE_ORDER, "matrix": matrix, "membership": {"source": "IdP groups → team.code", "attribute": svc.settings.entra_team_attr}, "sweeps": sweeps}


class PatBody(BaseModel):
    token: str
    expires: str  # ISO date


@router.put("/me/pat")
async def set_pat(body: PatBody, user: User = Depends(current_user), svc: Services = Depends(services)):
    """Store the caller's Azure Repos PAT in Key Vault (ado-pat-<oid>). Verified against Azure Repos before storing."""
    from ..clients.azure_repos import AzureRepos
    s = svc.settings
    probe = AzureRepos(s.ado_org, s.ado_project, s.ado_repo, pat=body.token)
    if await probe.branch_sha(s.ado_branch) is None:
        raise HTTPException(422, "token cannot read the schema repository; check organisation and scopes (Code read & write, Pull requests)")
    await store_pat(user, svc, body.token, body.expires)
    await audit(svc, user, "pat.set", user.upn, {"expires": body.expires})
    return await pat_status(user, svc)


@router.delete("/me/pat", status_code=204)
async def remove_pat(user: User = Depends(current_user), svc: Services = Depends(services)):
    await delete_pat(user, svc)
    await audit(svc, user, "pat.remove", user.upn)


@router.get("/audit")
async def audit_log(q: str | None = None, mine: bool = False, limit: int = 200, user: User = Depends(current_user), svc: Services = Depends(services)):
    """Who changed what. Studio actions from ops_audit; deployments from ops_deployment; PR completions come from Azure Repos."""
    async with svc.db.session() as s:
        ops = OpsRepo(s)
        rows = await ops.audit_rows(q, user.upn if mine else None, limit)
        dep = await ops.latest_deployment()
    out = [{"at": r.at.isoformat(), "upn": r.upn, "action": r.action, "target": r.target, "branch": r.branch, "commit": r.commit, "source": r.source, "detail": r.detail} for r in rows]
    if dep and (not q or q in "deploy"):
        out.append({"at": dep.deployed_at.isoformat(), "upn": "pipeline", "action": "deploy", "target": f"{svc.settings.environment} ← {dep.ref}", "branch": dep.ref, "commit": dep.commit, "source": "pipeline", "detail": {"run": dep.pipeline_run}})
    return {"environment": svc.settings.environment, "items": sorted(out, key=lambda r: r["at"], reverse=True)}
