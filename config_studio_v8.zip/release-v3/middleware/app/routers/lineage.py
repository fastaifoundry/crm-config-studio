"""Lineage: upstream / downstream graph plus who-what-when-how-why for one object or consumer.

GET /api/lineage/{kind}/{id}?cadence=15m|1h|1d&field=<name>&refresh=true

Joins, in one response, what the UI would otherwise fetch from five places:
  repo YAML (structure) · grants (who reads what) · ops_audit (who changed it) · ops_deployment (where it runs)
  · Monitor (usage at the requested cadence). Rollups read the pre-aggregated ops_catalog_snapshot written by the
  collector on that cadence. `refresh=true` pulls Log Analytics now (on demand, rate-limited per user) and stores the
  result as the newest snapshot for that cadence, so everyone benefits.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query

from ..auth import User, current_user
from ..db.repo import OpsRepo
from ..deps import Services, services
from ..models import Mode

router = APIRouter(prefix="/api/lineage", tags=["lineage"])
Cadence = Literal["now", "15m", "1h", "1d"]  # now = on-demand pull (default), others read rollups
_REFRESH_MIN_GAP = timedelta(minutes=2)
_last_refresh: dict[str, datetime] = {}


def _node(kind: str, id: str, title: str, sub: str = "", rel: str = "", **extra) -> dict:
    return {"kind": kind, "id": id, "title": title, "sub": sub, "rel": rel, **extra}


@router.get("/{kind}/{id}")
async def lineage(kind: Literal["object", "consumer"], id: str, cadence: Cadence = Query("now"), field: str | None = None, refresh: bool = False,
                  mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
    ref = await svc.repo.ref_for(mode, user)
    objects = await svc.repo.list("objects", ref)
    consumers = await svc.repo.consumers(ref)
    views, edges, graphs, picklists = (await svc.repo.list(k, ref) for k in ("views", "edges", "graph", "picklists"))
    by_api = {o["api_name"]: o for o in objects}
    if cadence == "now":
        await _refresh(svc, "now", user, force=refresh)
    elif refresh:
        await _refresh(svc, cadence, user)
    usage = await _usage(svc, cadence)                       # {identity: {"ru": int, "series": [..], "last_seen": iso}}
    ident = {c["hosting"]["managed_identity_client_id"]: c for c in consumers}

    up: list[dict] = []
    dn: list[dict] = []
    focus: dict
    if kind == "object":
        o = by_api.get(id) or _404(id)
        fields = o.get("fields", [])
        focus = {"kind": "object", "id": id, "title": id, "sub": f"{o['kind']} · {o['container']} · {o['owner']}",
                 "fields": [{"name": f["name"], "type": f["type"], "status": f.get("status", "active"), "pii": f.get("pii", "none"),
                             "readers": len(svc.repo.dependants("object", id, consumers, field=f["name"]))} for f in fields]}
        up.append(_node("container", o["container"], o["container"], f'_type = "{id}"', "stored in"))
        if o.get("managed_by") == "party_master":
            up.append(_node("master", "party_master", "party master", "fields and records mastered externally", "managed by"))
        if o.get("extends"):
            up.append(_node("base", o["extends"], o["extends"], "abstract base", "extends"))
        for f in fields:
            if f.get("picklist") and not any(n["kind"] == "picklist" and n["id"] == f["picklist"] for n in up):
                pl = next((p for p in picklists if p["name"] == f["picklist"]), {})
                up.append(_node("picklist", f["picklist"], f["picklist"], f"{len(pl.get('values', []))} values", "typed as", via=f["name"]))
            if f.get("type") == "lookup" and f.get("target") and not any(n["kind"] == "object" and n["id"] == f["target"] for n in up):
                up.append(_node("object", f["target"], f["target"], "lookup" + (" · carries " + ", ".join(f["display_fields"]) if f.get("display_fields") else ""), "references", via=f["name"]))
        for v in views:
            if v.get("object") == id:
                dn.append(_node("view", v["name"], v["name"], f"keyed by {v.get('partition_key')}", "projected into"))
        for e in edges:
            if id in e.get("from", []) or id in e.get("to", []):
                dn.append(_node("edge", e["name"], e["name"], f"{','.join(e.get('from', []))} → {','.join(e.get('to', []))}", "from here" if id in e.get("from", []) else "to here"))
        for x in objects:
            for f in x.get("fields", []):
                if f.get("type") == "lookup" and f.get("target") == id:
                    dn.append(_node("object", x["api_name"], x["api_name"], f"{f['name']} → {id}", "referenced by"))
        touched_edges = {n["id"] for n in dn if n["kind"] == "edge"}
        for g in graphs:
            if touched_edges & set(g.get("edges", [])):
                dn.append(_node("graph", g["name"], g["name"], f"depth {g.get('depth_cap')} · {g.get('owner')}", "traversed by"))
        max_ru = max([1] + [u["ru"] for u in usage.values()])
        for c in consumers:
            g = next((g for g in c.get("grants", []) if g.get("object") == id or (g.get("kind") == "object" and g.get("target") == id)), None)
            if not g:
                continue
            gfields = g.get("fields", [])
            if field and gfields != "*" and field not in gfields:
                continue
            u = usage.get(c["hosting"]["managed_identity_client_id"], {"ru": 0, "series": [], "last_seen": None})
            dn.append(_node("consumer", c["name"], c["name"], f"{g.get('access', 'r')} · {'all' if gfields == '*' else len(gfields)} fields · {len(g.get('queries', []))} queries · {c['hosting']['function_app']}",
                            "granted", ru=u["ru"], weight=1 + round(u["ru"] / max_ru * 4), series=u["series"], fields=[f["name"] for f in fields] if gfields == "*" else gfields))
        w5 = await _w5_object(svc, o, consumers, dn, cadence)
    else:
        c = next((c for c in consumers if c["name"] == id), None) or _404(id)
        focus = {"kind": "consumer", "id": id, "title": id, "sub": f"{c['type']} · {c['hosting']['function_app']} · {c['owner']}",
                 "fields": [{"name": f"{r['method']} {r['path']}", "type": "uses " + r["uses"]} for r in c.get("routes", [])]}
        for g in c.get("grants", []):
            gk = g.get("kind") or next(k for k in ("object", "view", "edge") if k in g)
            up.append(_node(gk, g.get("target") or g.get(gk), g.get("target") or g.get(gk), f"{g.get('access', 'r')}" if gk == "object" else gk, "grant on"))
        up.append(_node("master", c["hosting"]["managed_identity_client_id"], "managed identity", c["hosting"]["managed_identity_client_id"], "runs as"))
        u = usage.get(c["hosting"]["managed_identity_client_id"], {"ru": 0, "series": [], "last_seen": None})
        dn.append(_node("route", c.get("screen_id") or "integration", c.get("screen_id") or "integration", "screen" if c["type"] == "ui" else "downstream system", "serves", ru=u["ru"], series=u["series"]))
        for g in graphs:
            if id in g.get("callers", []):
                dn.append(_node("graph", g["name"], g["name"], f"depth {g.get('depth_cap')}", "calls"))
        w5 = await _w5_consumer(svc, c, u, cadence)

    return {"focus": focus, "upstream": up, "downstream": dn, "w5": w5, "cadence": cadence, "as_of": _as_of(cadence), "ref": ref}


# ---- usage at a cadence ----
async def _refresh(svc: Services, cadence: Cadence, user: User, force: bool = True) -> None:
    """On-demand pull. For cadence "now" without force, reuse the last pull if it is younger than the gap; with force
    (user clicked refresh) pull again, rate-limited per user so a click storm cannot hammer Log Analytics."""
    if cadence == "now" and not force:
        async with svc.db.session() as s:
            snap = await OpsRepo(s).latest_snapshot("usage_now")
        if snap and datetime.now(UTC) - snap.as_of.replace(tzinfo=UTC) < _REFRESH_MIN_GAP:
            return
    last = _last_refresh.get(user.oid)
    if force and last and datetime.now(UTC) - last < _REFRESH_MIN_GAP:
        raise HTTPException(429, f"refresh allowed every {int(_REFRESH_MIN_GAP.total_seconds() // 60)} minutes per user")
    _last_refresh[user.oid] = datetime.now(UTC)
    days = {"now": 1, "15m": 1, "1h": 1, "1d": 7}[cadence]
    rows = await svc.monitor.ru_by_identity(days=days) if svc.monitor.logs else []
    shapes = await svc.monitor.query_shapes(days=days) if svc.monitor.logs else []
    async with svc.db.session() as s:
        ops = OpsRepo(s)
        await ops.snapshot(f"usage_{cadence}", {"rows": rows, "shapes": shapes, "refreshed_by": user.upn, "on_demand": True})
        await ops.audit(user.upn, "usage.refresh", cadence, {"rows": len(rows)})


async def _usage(svc: Services, cadence: Cadence) -> dict[str, dict]:
    async with svc.db.session() as s:
        snap = await OpsRepo(s).latest_snapshot(f"usage_{cadence}")
    rows = (snap.payload if snap else {}).get("rows", [])
    out: dict[str, dict] = {}
    for r in rows:
        slot = out.setdefault(r["identity"], {"ru": 0, "series": [], "last_seen": None})
        slot["ru"] += int(r["ru"]); slot["series"].append(int(r["ru"]))
        slot["last_seen"] = max(slot["last_seen"] or str(r["TimeGenerated"]), str(r["TimeGenerated"]))
    return out


def _as_of(cadence: Cadence) -> str:
    now = datetime.now(UTC)
    return {"now": f"{now:%H:%M}Z · pulled on demand", "15m": f"{now.replace(minute=now.minute // 15 * 15):%H:%M}Z · 15-minute rollup",
            "1h": f"{now:%H}:00Z · hourly rollup", "1d": f"{now:%Y-%m-%d} 03:00Z · nightly batch"}[cadence]


# ---- who · what · when · how · why ----
async def _w5_object(svc: Services, o: dict, consumers: list[dict], dn: list[dict], cadence: Cadence) -> list[dict]:
    api = o["api_name"]
    async with svc.db.session() as s:
        ops = OpsRepo(s)
        audit = await ops.audit_rows(q=f"objects/{api}.yaml", limit=1)
        dep = await ops.latest_deployment()
    readers = [c["name"] for c in consumers if any((g.get("object") == api or g.get("target") == api) for g in c.get("grants", []))]
    last = audit[0] if audit else None
    ru = sum(n.get("ru", 0) for n in dn if n["kind"] == "consumer")
    return [
        {"k": "what", "v": f"{o.get('label', api)} · {o['kind']} object with {len(o.get('fields', []))} fields. {o.get('description', '')}"},
        {"k": "who", "v": f"Owned by {o['owner']}. Read by {len(readers)} consumer(s): {', '.join(readers) or 'none'}. Last changed by {last.upn + ' at ' + last.at.isoformat(timespec='minutes') if last else '—'}."},
        {"k": "when", "v": f"Deployed here from {dep.ref} @ {dep.commit} at {dep.deployed_at.isoformat(timespec='minutes')}" if dep else "Not deployed to this environment yet."},
        {"k": "how", "v": f"Stored in {o['container']} as _type = \"{api}\"; {sum(1 for f in o.get('fields', []) if f.get('filterable'))} indexed paths. Row-level security by team."},
        {"k": "why", "v": o.get("reason") or o.get("description", "")},
        {"k": "usage", "v": f"{ru:,} RU across {len(readers)} consumers · {_as_of(cadence)}"},
    ]


async def _w5_consumer(svc: Services, c: dict, u: dict, cadence: Cadence) -> list[dict]:
    async with svc.db.session() as s:
        audit = await OpsRepo(s).audit_rows(q=c["name"], limit=1)
    last = audit[0] if audit else None
    return [
        {"k": "what", "v": f"{c.get('label', c['name'])} · {c['type']} on {c['hosting']['function_app']} · {len(c.get('grants', []))} grants, {len(c.get('routes', []))} routes. {c.get('description', '')}"},
        {"k": "who", "v": f"Owned by {c['owner']}. Runs as {c['hosting']['managed_identity_client_id']}. Last changed by {last.upn if last else '—'}."},
        {"k": "when", "v": f"Last seen {u.get('last_seen') or 'never'} · status {c.get('status', 'draft')}."},
        {"k": "how", "v": f"Reads {', '.join(g.get('object') or g.get('target', '') for g in c.get('grants', []))} through {sum(len(g.get('queries', [])) for g in c.get('grants', []))} named queries; attributed in Monitor by identity."},
        {"k": "why", "v": c.get("description", "—")},
        {"k": "usage", "v": f"{u.get('ru', 0):,} RU" + (f" of {c['ru_budget_per_day']:,}/day budget" if c.get("ru_budget_per_day") else "") + f" · {_as_of(cadence)}"},
    ]


def _404(what: str):
    raise HTTPException(404, f"{what} not found")
