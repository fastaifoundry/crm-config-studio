from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from ..auth import User, require_design
from ..db.repo import OpsRepo
from ..deps import Services, services
from ..identity import audit, user_repo
from ..yamlrepo import YamlRepo
from ..models import ChangeSet

router = APIRouter(prefix="/api/changes", tags=["changes"])


class PrRequest(BaseModel):
    title: str


@router.get("", response_model=ChangeSet)
async def preview(user: User = Depends(require_design), svc: Services = Depends(services)):
    ref = await svc.repo.ref_for("design", user)  # type: ignore[arg-type]
    return await svc.repo.changeset(user, await svc.repo.list("objects", ref), await svc.repo.consumers(ref))


@router.post("/pr")
async def open_pr(body: PrRequest, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await svc.repo.ref_for("design", user)  # type: ignore[arg-type]
    cs = await svc.repo.changeset(user, await svc.repo.list("objects", ref), await svc.repo.consumers(ref))
    if not cs.files:
        return {"pr_url": None, "message": "nothing to submit"}
    if any(b.kind == "delete" for b in cs.breaking):
        return {"pr_url": None, "message": "deletion of an in-use definition is blocked; deprecate instead"}
    url = await repo.open_pr(user, cs, body.title)  # PR created by the user (their PAT)
    async with svc.db.session() as s:
        await OpsRepo(s).close_session(cs.branch, url)
    await audit(svc, user, "pr.open", url, {"files": [f.path for f in cs.files]}, cs.branch)
    return {"pr_url": url, "message": "Approve and complete the pull request in Azure DevOps; the schema pipeline deploys on merge."}


@router.delete("", status_code=204)
async def discard(user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    await repo.discard(user)
    await audit(svc, user, "branch.discard", user.session_branch, None, user.session_branch)
    async with svc.db.session() as s:
        await OpsRepo(s).close_session(user.session_branch, None)
