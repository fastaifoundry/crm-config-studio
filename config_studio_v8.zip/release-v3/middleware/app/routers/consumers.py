from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from ..auth import User, current_user, require_design
from ..deps import Services, services
from ..identity import audit, user_repo
from ..yamlrepo import YamlRepo
from ..models import ConsumerDef, Grant, Mode

router = APIRouter(prefix="/api/consumers", tags=["consumers"])


@router.get("")
async def list_consumers(mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
    ref = await svc.repo.ref_for(mode, user)
    items = await svc.repo.consumers(ref)
    if mode == Mode.catalog:
        usage = await svc.monitor.ru_by_identity()
        by_id: dict[str, dict] = {}
        for row in usage:
            slot = by_id.setdefault(row["identity"], {"ru_7d": 0, "last_seen": None})
            slot["ru_7d"] += int(row["ru"]); slot["last_seen"] = max(slot["last_seen"] or row["TimeGenerated"], row["TimeGenerated"])
        known = {c["hosting"]["managed_identity_client_id"] for c in items}
        for c in items:
            c["usage"] = by_id.get(c["hosting"]["managed_identity_client_id"], {"ru_7d": 0, "last_seen": None})
        return {"ref": ref, "items": items, "unregistered": [{"identity": k, **v} for k, v in by_id.items() if k not in known]}
    return {"ref": ref, "items": items}


@router.get("/function-apps")
async def function_apps(user: User = Depends(current_user), svc: Services = Depends(services)):
    """Tagged function apps not yet registered — what the Register form's dropdown shows."""
    apps = await svc.functions.apps()
    taken = {c["hosting"]["function_app"] for c in await svc.repo.consumers(svc.repo.base)}
    return [a for a in apps if a["name"] not in taken]


@router.get("/{name}")
async def get_consumer(name: str, mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
    typ, _, short = name.partition(".")
    c = await svc.repo.get("consumers", short, await svc.repo.ref_for(mode, user), sub=typ)
    if not c:
        raise HTTPException(404, f"consumer {name} not found")
    return c


@router.get("/{name}/routes")
async def routes(name: str, user: User = Depends(current_user), svc: Services = Depends(services)):
    typ, _, short = name.partition(".")
    c = await svc.repo.get("consumers", short, svc.repo.base, sub=typ) or _404(name)
    declared = c.get("routes", [])
    observed = await svc.functions.routes(c["hosting"]["function_app"])
    for d in declared:
        hit = next((o for o in observed if o["route"] == d["path"] and o["method"] == d["method"]), None)
        d["observed"] = {k: hit[k] for k in ("calls", "p95_ms", "failed")} if hit else None
    undeclared = [o for o in observed if not any(d["path"] == o["route"] and d["method"] == o["method"] for d in declared)]
    return {"declared": declared, "undeclared": undeclared}


@router.get("/{name}/usage")
async def usage(name: str, user: User = Depends(current_user), svc: Services = Depends(services)):
    typ, _, short = name.partition(".")
    c = await svc.repo.get("consumers", short, svc.repo.base, sub=typ) or _404(name)
    mi = c["hosting"]["managed_identity_client_id"]
    rows = [r for r in await svc.monitor.ru_by_identity() if r["identity"] == mi]
    shapes = [s for s in await svc.monitor.query_shapes() if s["identity"] == mi]
    return {"days": rows, "top_shapes": shapes, "budget": c.get("ru_budget_per_day")}


@router.post("", status_code=201)
async def register(body: ConsumerDef, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    # Grants may not exceed a field's channel exposure (UI consumers → exposure.ui, API consumers → exposure.api).
    ref = await svc.repo.ref_for(Mode.design, user)
    for g in body.grants:
        if g.kind == "object" and g.access == "rw":
            obj = await svc.repo.get("objects", g.target, ref)
            # metadata (platform) attributes may be granted for responses/filters; they are read-only by definition
            platform_names = {pf["name"] for c in await svc.repo.list("conventions", ref) for pf in c.get("fields", [])}
            for f in (obj or {}).get("fields", []):
                if (g.fields == "*" or f["name"] in g.fields) and f["name"] not in (g.read_only or []):
                    level = (f.get("exposure") or {}).get(body.type, "edit")
                    if level != "edit":
                        raise HTTPException(422, f"{g.target}.{f['name']} exceeds channel exposure: {level} on {body.type}; mark it read_only in the grant")
    _validate_grants(body.grants, body.type, user)
    if await svc.repo.get("consumers", body.name, svc.repo.base, sub=body.type):
        raise HTTPException(409, f"{body.type}.{body.name} already registered")
    doc = body.model_dump(exclude_none=True, exclude_defaults=True) | {"name": f"{body.type}.{body.name}", "type": body.type, "status": "draft"}
    commit = await repo.put("consumers", body.name, doc, user, f"Register consumer {body.type}.{body.name}", sub=body.type)
    await audit(svc, user, "consumer.register", doc["name"], {"commit": commit, "grants": len(body.grants)}, user.session_branch)
    return doc


@router.patch("/{name}")
async def update(name: str, body: ConsumerDef, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    typ, _, short = name.partition(".")
    _validate_grants(body.grants, body.type, user)
    existing = await svc.repo.get("consumers", short, await svc.repo.ref_for(Mode.design, user), sub=typ) or _404(name)
    doc = existing | body.model_dump(exclude_none=True, exclude_defaults=True) | {"name": name, "type": typ}
    commit = await repo.put("consumers", short, doc, user, f"Update consumer {name}", sub=typ)
    await audit(svc, user, "consumer.update", name, {"commit": commit}, user.session_branch)
    return doc


@router.delete("/{name}", status_code=204)
async def revoke(name: str, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    typ, _, short = name.partition(".")
    commit = await repo.remove("consumers", short, user, f"Revoke consumer {name}", sub=typ)
    await audit(svc, user, "consumer.revoke", name, {"commit": commit}, user.session_branch)


def _validate_grants(grants: list[Grant], typ: str, user: User) -> None:
    if not grants:
        raise HTTPException(422, "at least one grant")
    for g in grants:
        if g.kind == "object" and g.fields != "*" and not g.fields:
            raise HTTPException(422, f"object grant on {g.target} needs fields")
        if g.fields == "*" and typ == "api" and not user.is_architect:
            raise HTTPException(403, f"wildcard grant on {g.target} needs an architect")
        for q in g.queries:
            if not q.name:
                raise HTTPException(422, "every named query needs a name")


def _404(what: str):
    raise HTTPException(404, f"{what} not found")
