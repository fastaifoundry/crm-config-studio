from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from ..auth import User, current_user, require_design
from ..deps import Services, services
from ..identity import audit, user_repo
from ..yamlrepo import YamlRepo
from ..models import Deprecation, EdgeDef, FieldDef, Mode, ObjectDef, ObjectPatch, PicklistDef, PicklistValue, ViewDef

router = APIRouter(prefix="/api", tags=["schema"])


async def _ref(mode: Mode, user: User, svc: Services) -> str:
    return await svc.repo.ref_for(mode, user)


# ---------------- objects ----------------
@router.get("/objects")
async def list_objects(mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
    ref = await _ref(mode, user, svc)
    objects, consumers = await svc.repo.list("objects", ref), await svc.repo.consumers(ref)
    for o in objects:
        o["consumer_count"] = len(svc.repo.dependants("object", o["api_name"], consumers))
        o["field_count"] = len(o.get("fields", []))
    return {"ref": ref, "items": objects}


@router.get("/objects/{api}")
async def get_object(api: str, mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
    ref = await _ref(mode, user, svc)
    o = await svc.repo.get("objects", api, ref)
    if not o:
        raise HTTPException(404, f"object {api} not found")
    consumers = await svc.repo.consumers(ref)
    o["consumers"] = [c for c in consumers if c["name"] in svc.repo.dependants("object", api, consumers)]
    o["referenced_by"] = [{"object": x["api_name"], "field": f["name"]} for x in await svc.repo.list("objects", ref)
                          for f in x.get("fields", []) if f.get("type") == "lookup" and f.get("target") == api]
    return o


@router.post("/objects", status_code=201)
async def create_object(body: ObjectDef, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    if body.kind == "root":
        raise HTTPException(403, "root objects are defined by the party master")
    if await svc.repo.get("objects", body.api_name, svc.repo.base):
        raise HTTPException(409, f"{body.api_name} already exists")
    commit = await repo.put("objects", body.api_name, body.model_dump(exclude_none=True), user, f"Create object {body.api_name} (draft)")
    await audit(svc, user, "objects.write", body.api_name, {"commit": commit}, user.session_branch)
    return {"ok": True, "path": f"objects/{body.api_name}.yaml"}


@router.patch("/objects/{api}")
async def patch_object(api: str, body: ObjectPatch, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await _ref(Mode.design, user, svc)
    o = await svc.repo.get("objects", api, ref) or _404(api)
    o.update({k: v for k, v in body.model_dump(exclude_none=True).items()})
    commit = await repo.put("objects", api, o, user, f"Update {api}: {', '.join(body.model_dump(exclude_none=True))}")
    await audit(svc, user, "objects.write", api, {"commit": commit}, user.session_branch)
    return o


@router.post("/objects/{api}/deprecate")
async def deprecate_object(api: str, dep: Deprecation, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    svc.repo.check_deprecation(dep)
    ref = await _ref(Mode.design, user, svc)
    o = await svc.repo.get("objects", api, ref) or _404(api)
    o.update(status="deprecated", sunset=dep.sunset, reason=dep.reason)
    commit = await repo.put("objects", api, o, user, f"Deprecate {api}, sunset {dep.sunset}")
    await audit(svc, user, "objects.write", api, {"commit": commit}, user.session_branch)
    return {"ok": True, "dependants": svc.repo.dependants("object", api, await svc.repo.consumers(ref))}


@router.delete("/objects/{api}", status_code=204)
async def delete_object(api: str, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await _ref(Mode.design, user, svc)
    deps = svc.repo.dependants("object", api, await svc.repo.consumers(ref))
    if deps:
        raise HTTPException(409, {"message": "consumers depend on this object; deprecate instead", "dependants": deps})
    commit = await repo.remove("objects", api, user, f"Delete object {api}")
    await audit(svc, user, "objects.delete", api, {"commit": commit}, user.session_branch)


# ---------------- fields ----------------
@router.post("/objects/{api}/fields", status_code=201)
async def add_field(api: str, body: FieldDef, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await _ref(Mode.design, user, svc)
    o = await svc.repo.get("objects", api, ref) or _404(api)
    names = {f["name"] for f in o.get("fields", [])} | {"id", "party_id", "team_id", "created_at", "created_by", "updated_at", "updated_by", "deleted_at", "version", "_type"}
    if body.name in names:
        raise HTTPException(409, f"field {body.name} already exists on {api}")
    body.managed_by = "crm"  # fields added here are always CRM-managed, even on master-managed objects
    o.setdefault("fields", []).append(body.model_dump(exclude_none=True, exclude_defaults=True) | {"name": body.name, "type": body.type})
    commit = await repo.put("objects", api, o, user, f"Add {api}.{body.name} ({body.type})")
    await audit(svc, user, "objects.write", api, {"commit": commit}, user.session_branch)
    return {"ok": True, "indexed": body.filterable}


@router.patch("/objects/{api}/fields/{name}")
async def edit_field(api: str, name: str, body: FieldDef, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await _ref(Mode.design, user, svc)
    o = await svc.repo.get("objects", api, ref) or _404(api)
    for i, f in enumerate(o.get("fields", [])):
        if f["name"] == name:
            if f.get("managed_by") == "party_master":
                raise HTTPException(403, f"{api}.{name} is defined by the party master")
            if f["type"] != body.type:
                raise HTTPException(422, "type changes are a new field + migration, not an edit")
            o["fields"][i] = body.model_dump(exclude_none=True, exclude_defaults=True) | {"name": name, "type": body.type}
            commit = await repo.put("objects", api, o, user, f"Edit {api}.{name}")
            await audit(svc, user, "objects.write", api, {"commit": commit}, user.session_branch)
            return o["fields"][i]
    raise HTTPException(404, f"field {name} not found")


@router.post("/objects/{api}/fields/{name}/deprecate")
async def deprecate_field(api: str, name: str, dep: Deprecation, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    svc.repo.check_deprecation(dep)
    ref = await _ref(Mode.design, user, svc)
    o = await svc.repo.get("objects", api, ref) or _404(api)
    f = next((f for f in o.get("fields", []) if f["name"] == name), None) or _404(f"{api}.{name}")
    f.update(status="deprecated", sunset=dep.sunset, reason=dep.reason)
    commit = await repo.put("objects", api, o, user, f"Deprecate {api}.{name}, sunset {dep.sunset}")
    await audit(svc, user, "objects.write", api, {"commit": commit}, user.session_branch)
    return {"ok": True, "dependants": svc.repo.dependants("object", api, await svc.repo.consumers(ref), field=name)}


# ---------------- edges / picklists / views / graph ----------------
def _simple(kind: str, model, name_key: str = "name"):
    r = APIRouter()

    @r.get(f"/{kind}")
    async def _list(mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
        ref = await _ref(mode, user, svc)
        return {"ref": ref, "items": await svc.repo.list(kind, ref)}

    @r.get(f"/{kind}/{{name}}")
    async def _get(name: str, mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
        return await svc.repo.get(kind, name, await _ref(mode, user, svc)) or _404(name)

    @r.post(f"/{kind}", status_code=201)
    async def _create(body: model, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):  # type: ignore[valid-type]
        d = body.model_dump(by_alias=True, exclude_none=True)
        if await svc.repo.get(kind, d[name_key], svc.repo.base):
            raise HTTPException(409, f"{d[name_key]} already exists")
        commit = await repo.put(kind, d[name_key], d, user, f"Create {kind[:-1]} {d[name_key]}")
        await audit(svc, user, f"{kind}.write", d[name_key], {"commit": commit}, user.session_branch)
        return d

    @r.patch(f"/{kind}/{{name}}")
    async def _patch(name: str, body: dict, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
        ref = await _ref(Mode.design, user, svc)
        d = await svc.repo.get(kind, name, ref) or _404(name)
        for k in ("name", "from", "to", "object"):  # immutable keys
            body.pop(k, None)
        d.update(body)
        commit = await repo.put(kind, name, d, user, f"Update {kind[:-1]} {name}")
        await audit(svc, user, f"{kind}.write", name, {"commit": commit}, user.session_branch)
        return d

    @r.post(f"/{kind}/{{name}}/deprecate")
    async def _dep(name: str, dep: Deprecation, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
        svc.repo.check_deprecation(dep)
        ref = await _ref(Mode.design, user, svc)
        d = await svc.repo.get(kind, name, ref) or _404(name)
        d.update(status="deprecated", sunset=dep.sunset, reason=dep.reason)
        commit = await repo.put(kind, name, d, user, f"Deprecate {kind[:-1]} {name}")
        await audit(svc, user, f"{kind}.write", name, {"commit": commit}, user.session_branch)
        return d

    @r.delete(f"/{kind}/{{name}}", status_code=204)
    async def _delete(name: str, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
        ref = await _ref(Mode.design, user, svc)
        consumers = await svc.repo.consumers(ref)
        deps = svc.repo.dependants(kind[:-1], name, consumers) if kind in ("edges", "views") else []
        if kind == "picklists":
            deps = [f"{o['api_name']}.{f['name']}" for o in await svc.repo.list("objects", ref) for f in o.get("fields", []) if f.get("picklist") == name]
        if deps:
            raise HTTPException(409, {"message": "still in use; deprecate instead", "dependants": deps})
        commit = await repo.remove(kind, name, user, f"Delete {kind[:-1]} {name}")
        await audit(svc, user, f"{kind}.delete", name, {"commit": commit}, user.session_branch)

    return r


router.include_router(_simple("edges", EdgeDef))
router.include_router(_simple("picklists", PicklistDef))
router.include_router(_simple("views", ViewDef))


@router.post("/picklists/{name}/values", status_code=201)
async def add_value(name: str, body: PicklistValue, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await _ref(Mode.design, user, svc)
    p = await svc.repo.get("picklists", name, ref) or _404(name)
    if any(v["value"] == body.value for v in p["values"]):
        raise HTTPException(409, f"{body.value} already exists")
    p["values"].append(body.model_dump(exclude_none=True, exclude_defaults=True) | {"value": body.value, "label": body.label})
    commit = await repo.put("picklists", name, p, user, f"Add {name}.{body.value}")
    await audit(svc, user, "picklists.write", name, {"commit": commit}, user.session_branch)
    return p


@router.post("/picklists/{name}/values/{value}/deprecate")
async def deprecate_value(name: str, value: str, dep: Deprecation, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    svc.repo.check_deprecation(dep)
    ref = await _ref(Mode.design, user, svc)
    p = await svc.repo.get("picklists", name, ref) or _404(name)
    v = next((v for v in p["values"] if v["value"] == value), None) or _404(f"{name}.{value}")
    v.update(status="deprecated", sunset=dep.sunset, reason=dep.reason)
    commit = await repo.put("picklists", name, p, user, f"Deprecate {name}.{value}")
    await audit(svc, user, "picklists.write", name, {"commit": commit}, user.session_branch)
    return p


@router.get("/graph-queries")
async def graph_queries(mode: Mode = Query(Mode.catalog), user: User = Depends(current_user), svc: Services = Depends(services)):
    ref = await _ref(mode, user, svc)
    items = await svc.repo.list("graph", ref)
    if svc.monitor.logs:  # last run cost from query statistics, matched on the graph name tag
        shapes = await svc.monitor.query_shapes()
        for g in items:
            hit = next((s for s in shapes if f"graph:{g['name']}" in (s.get("QueryText") or "")), None)
            g["last_run_ru"] = round(hit["ru"] / max(hit["calls"], 1)) if hit else None
    return {"ref": ref, "items": items, "as_of": datetime.now(UTC).isoformat(timespec="seconds")}


def _404(what: str):
    raise HTTPException(404, f"{what} not found")


# ---------------- graph queries (any design user may register or edit; the pipeline validates cost and latency) ----------------
class GraphQueryDef(BaseModel):
    name: str = Field(pattern=r"^[a-z][a-z0-9_]{2,59}$")
    parameters: list[str]
    edges: list[str] = Field(min_length=1)
    depth_cap: int = Field(ge=1, le=6)
    latency_target_ms: int = Field(ge=50, le=10000)
    owner_consumer: str
    returns: list[str] = []
    description: str = Field(min_length=20)


@router.put("/graph-queries/{name}")
async def put_graph_query(name: str, body: GraphQueryDef, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    if body.name != name:
        raise HTTPException(422, "name in path and body differ")
    ref = await svc.repo.ref_for(Mode.design, user)
    edges = {e["name"] for e in await svc.repo.list("edges", ref)}
    unknown = [e for e in body.edges if e not in edges]
    if unknown:
        raise HTTPException(422, f"unknown edges: {', '.join(unknown)}")
    existing = await svc.repo.get("graph", name, ref)
    doc = {**(existing or {}), **body.model_dump(), "status": (existing or {}).get("status", "draft"), "callers": (existing or {}).get("callers") or [{"name": body.owner_consumer, "note": "owner"}]}
    commit = await repo.put("graph", name, doc, user, f"{'Update' if existing else 'Register'} graph query {name}")
    await audit(svc, user, "graph.update" if existing else "graph.register", name, {"commit": commit, "depth_cap": body.depth_cap}, user.session_branch)
    return {"ok": True, "path": f"graph/{name}.yaml", "commit": commit, "note": "the pipeline runs the traversal once against test data and fails the release if it misses the latency target"}


@router.post("/graph-queries/{name}/deprecate")
async def deprecate_graph_query(name: str, body: Deprecation, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await svc.repo.ref_for(Mode.design, user)
    g = await svc.repo.get("graph", name, ref)
    if not g:
        raise HTTPException(404, f"graph query {name} not found")
    g.update({"status": "deprecated", "sunset": body.sunset, "reason": body.reason})
    commit = await repo.put("graph", name, g, user, f"Deprecate graph query {name} · sunset {body.sunset}")
    await audit(svc, user, "graph.deprecate", name, {"commit": commit, "sunset": body.sunset}, user.session_branch)
    return {"ok": True, "commit": commit}
