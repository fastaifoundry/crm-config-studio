from __future__ import annotations

import asyncio
from datetime import UTC, datetime

from cachetools import TTLCache
from fastapi import APIRouter, Depends, Header

from ..auth import User, current_user
from ..deps import Services, services

router = APIRouter(prefix="/api/catalog", tags=["catalog"])
_cache: TTLCache = TTLCache(maxsize=8, ttl=900)


@router.get("/containers")
async def containers(user: User = Depends(current_user), svc: Services = Depends(services), refresh: str | None = Header(None, alias="X-Studio-Refresh")):
    if "containers" in _cache and not refresh:
        return _cache["containers"]
    snap = await svc.cosmos.snapshot()
    accounts = {(c["account"],) for c in snap}
    rgs = {a.name: a.resource_group for a in await svc.cosmos.accounts()}
    metrics = dict()
    for (acc,) in accounts:
        metrics[acc] = await svc.monitor.container_metrics(rgs[acc], acc)
    tops = await asyncio.gather(*(svc.monitor.top_partitions(c["database"], c["name"]) for c in snap), return_exceptions=True)
    for c, top in zip(snap, tops):
        m = metrics.get(c["account"], {}).get((c["database"], c["name"]), {})
        total_bytes = m.get("data_bytes", 0) + m.get("index_bytes", 0)
        c["size_gb"] = round(total_bytes / 1024**3, 1)
        c["document_count"] = m.get("document_count", 0)
        c["ru_24h"] = m.get("ru_24h", 0)
        c["top_partitions"] = [t | {"pct": round(t["size_gb"] * 1024**3 / total_bytes * 100) if total_bytes else 0} for t in (top if isinstance(top, list) else [])]
    # objects → containers, from the repo, so the screen can show which objects live where
    objects = await svc.repo.list("objects", svc.repo.base)
    for c in snap:
        c["objects"] = [o["api_name"] for o in objects if o.get("container") == c["name"]]
    result = {"as_of": datetime.now(UTC).isoformat(timespec="seconds"), "containers": snap}
    _cache["containers"] = result
    return result


@router.get("/usage")
async def usage(user: User = Depends(current_user), svc: Services = Depends(services)):
    consumers = await svc.repo.consumers(svc.repo.base)
    by_mi = {c["hosting"]["managed_identity_client_id"]: c["name"] for c in consumers}
    rows = await svc.monitor.ru_by_identity()
    shapes = await svc.monitor.query_shapes()
    per_consumer: dict[str, dict] = {}
    unregistered: dict[str, int] = {}
    for r in rows:
        name = by_mi.get(r["identity"])
        if name:
            per_consumer.setdefault(name, {"days": {}, "total": 0})
            per_consumer[name]["days"][r["TimeGenerated"][:10]] = per_consumer[name]["days"].get(r["TimeGenerated"][:10], 0) + int(r["ru"])
            per_consumer[name]["total"] += int(r["ru"])
        else:
            unregistered[r["identity"]] = unregistered.get(r["identity"], 0) + int(r["ru"])
    objects = await svc.repo.list("objects", svc.repo.base)
    deprecated = [{"field": f"{o['api_name']}.{f['name']}", "sunset": f.get("sunset"),
                   "consumers": svc.repo.dependants("object", o["api_name"], consumers, field=f["name"])}
                  for o in objects for f in o.get("fields", []) if f.get("status") == "deprecated"]
    return {"as_of": datetime.now(UTC).isoformat(timespec="seconds"), "consumers": per_consumer,
            "top_shapes": [{**s, "consumer": by_mi.get(s["identity"], "unregistered")} for s in shapes],
            "unregistered": [{"identity": k, "ru_7d": v} for k, v in unregistered.items()],
            "deprecated_in_use": [d for d in deprecated if d["consumers"]]}


@router.get("/deployment")
async def deployment(user: User = Depends(current_user), svc: Services = Depends(services)):
    """What this environment runs (from ops_deployment) versus main (from Azure Repos)."""
    from ..db.repo import OpsRepo
    async with svc.db.session() as s:
        dep = await OpsRepo(s).latest_deployment()
    main_sha = await svc.git.branch_sha(svc.repo.base)
    return {"environment": svc.settings.environment, "catalog_only": svc.settings.environment == "prod",
            "deployed": {"ref": dep.ref, "commit": dep.commit, "at": dep.deployed_at.isoformat(), "objects": dep.objects, "consumers": dep.consumers} if dep else None,
            "main_commit": main_sha, "equals_main": bool(dep and main_sha and main_sha.startswith(dep.commit))}


@router.get("/releases")
async def releases(user: User = Depends(current_user), svc: Services = Depends(services)):
    return await svc.git.releases(10)
