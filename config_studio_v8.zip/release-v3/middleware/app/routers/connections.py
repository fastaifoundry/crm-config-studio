"""What the Settings screen calls: which connections are configured, and a live test of each."""
from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..auth import User, current_user, require_architect
from ..db.repo import OpsRepo
from ..deps import Services, services
from ..models import ConnectionStatus

router = APIRouter(prefix="/api/connections", tags=["connections"])

TITLES = {"repo": "Schema repository (Azure Repos)", "pipelines": "Azure Pipelines", "cosmos": "Cosmos DB", "monitor": "Azure Monitor", "functions": "Azure Functions",
          "keyvault": "Azure Key Vault", "sql": "Azure SQL (audit & sessions)", "idp": "Identity provider", "party_master": "Party master"}


@router.get("")
async def list_connections(user: User = Depends(current_user), svc: Services = Depends(services)):
    s = svc.settings
    cfg = {
        "repo": {"org": s.ado_org, "project": s.ado_project, "repo": s.ado_repo, "branch": s.ado_branch, "path": s.ado_schema_path, "auth": s.ado_auth},
        "pipelines": {"pipeline_id": s.ado_pipeline_id},
        "cosmos": {"discover": "tag", "tag": s.cosmos_tag, "identity": s.managed_identity_client_id or "system-assigned", "discriminator": s.cosmos_discriminator},
        "monitor": {"workspace": s.log_analytics_workspace_id, "refresh_minutes": s.monitor_refresh_minutes},
        "functions": {"tag": s.functions_tag, "resource_group": s.functions_resource_group, "app_insights": s.app_insights},
        "keyvault": {"url": s.keyvault_url},
        "sql": {"server": s.sql_server, "database": s.sql_database, "auth": s.sql_auth, "schema": s.sql_schema},
        "idp": {"tenant": s.entra_tenant_id, "audience": s.entra_audience, "groups_claim": s.entra_groups_claim, "team_attr": s.entra_team_attr},
        "party_master": {"url": s.party_master_url},
    }
    # Values saved from the Settings screen (ops_connection.config, this environment's SQL) override the deployment defaults.
    async with svc.db.session() as s:
        ops = OpsRepo(s)
        for k in cfg:
            cfg[k] = {**cfg[k], **(await ops.connection_config(k))}
    return [{"id": k, "title": TITLES[k], "config": v, "configured": all(x not in (None, "", []) for x in v.values())} for k, v in cfg.items()]


class ConnectionConfig(BaseModel):
    config: dict


@router.put("/{conn_id}")
async def save_connection(conn_id: str, body: ConnectionConfig, user: User = Depends(require_architect), svc: Services = Depends(services)):
    """Persist non-secret connection settings for this environment. Secrets are Key Vault names, never values."""
    if conn_id not in TITLES:
        raise HTTPException(404, "unknown connection")
    if any(k.lower() in ("password", "pat", "token", "secret", "key") for k in body.config):
        raise HTTPException(422, "secrets are not stored here; put them in Key Vault and reference the secret name")
    async with svc.db.session() as s:
        ops = OpsRepo(s)
        await ops.record_connection(conn_id, body.config, "saved", "settings updated", user.upn)
        await ops.audit(user.upn, "connection.update", conn_id, {"env": svc.settings.environment, "keys": list(body.config)})
    return {"ok": True, "environment": svc.settings.environment}


# ---------------- environment parameters (ops_setting) ----------------
settings_router = APIRouter(prefix="/api/settings", tags=["settings"])

PARAM_DEFAULTS = {
    "dev":  {"lineage_cadence": "now", "refresh_min_gap_min": 2,  "ru_warn_pct": 80, "sunset_default_days": 180, "pr_reviewers": "@crm/schema-owners", "usage_window_days": 7,  "purge_after_days": 30},
    "test": {"lineage_cadence": "15m", "refresh_min_gap_min": 5,  "ru_warn_pct": 80, "sunset_default_days": 180, "pr_reviewers": "@crm/schema-owners", "usage_window_days": 7,  "purge_after_days": 30},
    "acc":  {"lineage_cadence": "1h",  "refresh_min_gap_min": 10, "ru_warn_pct": 90, "sunset_default_days": 180, "pr_reviewers": "@crm/schema-owners, @crm/architects", "usage_window_days": 14, "purge_after_days": 90},
    "prod": {"lineage_cadence": "1d",  "refresh_min_gap_min": 15, "ru_warn_pct": 90, "sunset_default_days": 365, "pr_reviewers": "@crm/schema-owners, @crm/architects, @crm/platform", "usage_window_days": 30, "purge_after_days": 365},
}


async def effective_settings(svc: Services) -> dict:
    """Defaults for this environment overlaid with what is stored in ops_setting. Used by lineage (cadence, refresh gap), catalog (usage window, RU warning) and deprecation forms (sunset)."""
    async with svc.db.session() as s:
        stored = await OpsRepo(s).settings()
    return {**PARAM_DEFAULTS.get(svc.settings.environment, PARAM_DEFAULTS["dev"]), **stored}


@settings_router.get("")
async def get_settings_(user: User = Depends(current_user), svc: Services = Depends(services)):
    return {"environment": svc.settings.environment, "values": await effective_settings(svc), "defaults": PARAM_DEFAULTS.get(svc.settings.environment, {})}


class SettingsPatch(BaseModel):
    values: dict


@settings_router.put("")
async def put_settings(body: SettingsPatch, user: User = Depends(require_architect), svc: Services = Depends(services)):
    unknown = [k for k in body.values if k not in PARAM_DEFAULTS["dev"]]
    if unknown:
        raise HTTPException(422, f"unknown parameters: {', '.join(unknown)}")
    async with svc.db.session() as s:
        ops = OpsRepo(s)
        for k, v in body.values.items():
            await ops.set_setting(k, v, user.upn)
        await ops.audit(user.upn, "settings.update", svc.settings.environment, {"keys": list(body.values)})
    return {"ok": True, "environment": svc.settings.environment, "values": await effective_settings(svc)}


@router.post("/{conn_id}/test", response_model=ConnectionStatus)
async def test(conn_id: str, user: User = Depends(require_architect), svc: Services = Depends(services)):
    if conn_id not in TITLES:
        raise HTTPException(404, "unknown connection")
    now = datetime.now(UTC).isoformat(timespec="seconds")
    try:
        msg, status = await _probe(conn_id, svc), "connected"
    except Exception as e:  # report, don't raise — the screen shows the message
        msg, status = f"{type(e).__name__}: {e}", "error"
    if conn_id != "sql":  # persist the result (skip when the store itself is what failed)
        try:
            async with svc.db.session() as s:
                repo = OpsRepo(s)
                await repo.record_connection(conn_id, {}, status, msg, user.upn)
                await repo.audit(user.upn, "connection.test", conn_id, {"status": status})
        except Exception:
            pass
    return ConnectionStatus(id=conn_id, title=TITLES[conn_id], status=status, checked_at=now, message=msg)


async def _probe(conn_id: str, svc: Services) -> str:
    s = svc.settings
    match conn_id:
        case "repo":
            tree = await svc.git.tree(s.ado_branch, s.ado_schema_path)
            counts: dict[str, int] = {}
            for b in tree:
                top = b["path"].removeprefix(s.ado_schema_path.strip("/") + "/").split("/")[0]
                counts[top] = counts.get(top, 0) + 1
            return f"{s.ado_org}/{s.ado_project}/{s.ado_repo}@{s.ado_branch} · " + " · ".join(f"{v} {k}" for k, v in sorted(counts.items()))
        case "pipelines":
            runs = await svc.git.check_runs(s.ado_branch)
            return f"pipeline {s.ado_pipeline_id}: " + (", ".join(f"{r['name']}={r['conclusion']}" for r in runs) or "no runs on main yet")
        case "cosmos":
            accs = await svc.cosmos.accounts()
            return f"{len(accs)} account(s) by tag {s.cosmos_tag}\n" + "\n".join(f"  {a.name} ({a.resource_group}): {', '.join(a.databases)}" for a in accs)
        case "monitor":
            accs = await svc.cosmos.accounts()
            if not accs:
                return "no Cosmos accounts to read metrics for"
            m = await svc.monitor.container_metrics(accs[0].resource_group, accs[0].name, hours=1)
            la = "Log Analytics connected" if svc.monitor.logs else "metrics only · no Log Analytics workspace"
            return f"{len(m)} container series on {accs[0].name} · {la}"
        case "functions":
            apps = await svc.functions.apps()
            return f"{len(apps)} function app(s) by tag {s.functions_tag} · App Insights: {', '.join(s.app_insights) or 'none'}"
        case "keyvault":
            return f"{await svc.kv.ping()} secrets visible"
        case "sql":
            return await svc.db.ping()
        case "idp":
            from ..auth import _jwks
            _jwks(s.entra_tenant_id)
            return f"tenant {s.entra_tenant_id[:8]}… · JWKS reachable · audience {s.entra_audience}"
        case "party_master":
            if not svc.party_master:
                raise RuntimeError("PARTY_MASTER_URL not set")
            h = await svc.party_master.health()
            return f"reachable · {h}"
    raise RuntimeError("unreachable")
