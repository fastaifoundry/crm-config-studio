"""Conventions: platform fields defined once per convention (conventions/<id>.yaml) and carried by every object
whose kind or `conventions` list includes it. Editing here changes every affected object in one commit."""
from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from ..auth import User, current_user, require_design
from ..deps import Services, services
from ..identity import audit, user_repo
from ..models import Deprecation, Mode
from ..yamlrepo import YamlRepo

router = APIRouter(prefix="/api/conventions", tags=["conventions"])

# Which objects a convention applies to. identity/security are structural; the rest come from the object's conventions list.
STRUCTURAL = {"identity": lambda o: True, "security": lambda o: o.get("kind") in ("party-scoped", "timeline")}


class PlatformField(BaseModel):
    name: str = Field(pattern=r"^[a-z][a-z0-9_]{1,39}$")
    type: str = Field(pattern=r"^(string|datetime|integer|boolean)$")
    filterable: bool = True
    sortable: bool = False
    description: str = Field(min_length=10)


class PlatformFieldPatch(BaseModel):
    filterable: bool | None = None
    sortable: bool | None = None
    description: str | None = Field(default=None, min_length=10)
    convention: str | None = None  # move to another convention


def applies(conv: dict, o: dict) -> bool:
    f = STRUCTURAL.get(conv["id"])
    return f(o) if f else conv["id"] in (o.get("conventions") or [])


async def _load(svc: Services, ref: str) -> tuple[list[dict], list[dict]]:
    return await svc.repo.list("conventions", ref), await svc.repo.list("objects", ref)


@router.get("")
async def list_conventions(mode: Mode = Query(Mode.design), user: User = Depends(current_user), svc: Services = Depends(services)):
    ref = await svc.repo.ref_for(mode, user)
    convs, objects = await _load(svc, ref)
    for c in convs:
        aff = [o["api_name"] for o in objects if applies(c, o)]
        c["affected"] = aff
        c["affected_count"] = len(aff)
    return {"ref": ref, "items": convs}


async def _conv(svc: Services, ref: str, conv: str) -> dict:
    c = await svc.repo.get("conventions", conv, ref)
    if not c:
        raise HTTPException(404, f"convention {conv} not found")
    c.setdefault("fields", [])
    return c


@router.post("/{conv}/fields", status_code=201)
async def add_field(conv: str, body: PlatformField, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await svc.repo.ref_for(Mode.design, user)
    c = await _conv(svc, ref, conv)
    convs, objects = await _load(svc, ref)
    taken = {f["name"] for k in convs for f in k.get("fields", [])} | {f["name"] for o in objects for f in o.get("fields", [])}
    if body.name in taken:
        raise HTTPException(409, f"{body.name} already exists as a platform or object field")
    c["fields"].append({**body.model_dump(), "status": "draft"})
    commit = await repo.put("conventions", conv, c, user, f"Add platform field {body.name} to {conv}")
    affected = [o["api_name"] for o in objects if applies(c, o)]
    await audit(svc, user, "convention.field.add", f"{conv}.{body.name}", {"commit": commit, "affected": len(affected)}, user.session_branch)
    return {"ok": True, "path": f"conventions/{conv}.yaml", "affected": affected, "note": "pipeline backfills existing documents as null; filterable fields add an index path to every affected container"}


@router.patch("/{conv}/fields/{name}")
async def update_field(conv: str, name: str, body: PlatformFieldPatch, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await svc.repo.ref_for(Mode.design, user)
    c = await _conv(svc, ref, conv)
    f = next((x for x in c["fields"] if x["name"] == name), None)
    if not f:
        raise HTTPException(404, f"{name} not in {conv}")
    patch = body.model_dump(exclude_none=True)
    target = patch.pop("convention", None)
    f.update(patch)
    commits = []
    if target and target != conv:  # move between conventions: two files, one branch
        t = await _conv(svc, ref, target)
        c["fields"] = [x for x in c["fields"] if x["name"] != name]
        t["fields"].append(f)
        commits.append(await repo.put("conventions", target, t, user, f"Move platform field {name} to {target}"))
    commits.append(await repo.put("conventions", conv, c, user, f"Update platform field {name}"))
    await audit(svc, user, "convention.field.update", f"{conv}.{name}", {"commit": commits[-1], "changes": list(patch) + (["convention"] if target else [])}, user.session_branch)
    return {"ok": True, "commits": commits}


@router.post("/{conv}/fields/{name}/deprecate")
async def deprecate_field(conv: str, name: str, body: Deprecation, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    ref = await svc.repo.ref_for(Mode.design, user)
    c = await _conv(svc, ref, conv)
    f = next((x for x in c["fields"] if x["name"] == name), None)
    if not f:
        raise HTTPException(404, f"{name} not in {conv}")
    f.update({"status": "deprecated", "sunset": body.sunset, "reason": body.reason, "deprecated_at": datetime.now(UTC).date().isoformat()})
    commit = await repo.put("conventions", conv, c, user, f"Deprecate platform field {name} · sunset {body.sunset}")
    await audit(svc, user, "convention.field.deprecate", f"{conv}.{name}", {"commit": commit, "sunset": body.sunset}, user.session_branch)
    return {"ok": True, "commit": commit}


@router.delete("/{conv}/fields/{name}", status_code=204)
async def remove_field(conv: str, name: str, user: User = Depends(require_design), svc: Services = Depends(services), repo: YamlRepo = Depends(user_repo)):
    """Only for fields that never reached an active release (status draft). Anything else must be deprecated."""
    ref = await svc.repo.ref_for(Mode.design, user)
    c = await _conv(svc, ref, conv)
    f = next((x for x in c["fields"] if x["name"] == name), None)
    if not f:
        raise HTTPException(404, f"{name} not in {conv}")
    if f.get("status") != "draft":
        raise HTTPException(409, "active platform fields are deprecated with a sunset, not deleted")
    c["fields"] = [x for x in c["fields"] if x["name"] != name]
    commit = await repo.put("conventions", conv, c, user, f"Remove draft platform field {name}")
    await audit(svc, user, "convention.field.delete", f"{conv}.{name}", {"commit": commit}, user.session_branch)
