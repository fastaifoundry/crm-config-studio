"""JSON shapes exchanged with the Vue UI. Field names match the prototype's YAML."""
from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, Field, field_validator

SNAKE = r"^[a-z][a-z0-9_]{1,39}$"
KEBAB = r"^[a-z][a-z0-9-]{2,40}$"


class Mode(StrEnum):
    design = "design"
    catalog = "catalog"


class Status(StrEnum):
    draft = "draft"
    active = "active"
    deprecated = "deprecated"


class Security(BaseModel):
    read: list[str] = []
    write: list[str] = []


class Exposure(BaseModel):
    """Channel-level control, independent of roles (RLS) and consumer grants: what UI screens and API integrations may do."""
    ui: Literal["edit", "view", "hidden"] = "edit"
    api: Literal["edit", "view", "hidden"] = "edit"


class FieldDef(BaseModel):
    exposure: Exposure = Field(default_factory=Exposure)
    name: str = Field(pattern=SNAKE)
    type: str
    max_length: int | None = None
    precision: int | None = None
    scale: int | None = None
    picklist: str | None = None
    target: str | None = None
    display_fields: list[str] = []
    required: bool = False
    pii: Literal["none", "personal", "sensitive"] = "none"
    filterable: bool = False
    sortable: bool = False
    unique: Literal["none", "customer", "global"] = "none"
    security: Security = Security()
    status: Status = Status.active
    sunset: str | None = None
    reason: str | None = None
    description: str = Field(min_length=10)
    managed_by: Literal["crm", "party_master"] = "crm"

    @field_validator("display_fields")
    @classmethod
    def _only_lookups(cls, v, info):
        if v and info.data.get("type") != "lookup":
            raise ValueError("display_fields only apply to lookup fields")
        return v


class ObjectDef(BaseModel):
    api_name: str = Field(pattern=SNAKE)
    label: str
    kind: Literal["root", "party-scoped", "global", "abstract"]
    extends: str | None = None
    container: str
    owner: str
    managed_by: Literal["crm", "party_master"] = "crm"
    status: Status = Status.draft
    sunset: str | None = None
    description: str = Field(min_length=10)
    conventions: list[str] = ["audit", "soft_delete"]
    fields: list[FieldDef] = []


class ObjectPatch(BaseModel):
    label: str | None = None
    description: str | None = None
    owner: str | None = None
    status: Status | None = None


class Deprecation(BaseModel):
    reason: str = Field(min_length=10)
    sunset: str  # ISO date, >= 90 days out (checked in router)


class EdgeDef(BaseModel):
    name: str = Field(pattern=SNAKE)
    owner: str
    from_: list[str] = Field(alias="from")
    to: list[str]
    roles: list[str]
    mirror: bool = False
    traversable: bool = False
    max_depth: int | None = None
    display_fields: dict[str, list[str]] = {}
    fields: list[FieldDef] = []
    description: str
    status: Status = Status.active

    model_config = {"populate_by_name": True}


class PicklistValue(BaseModel):
    value: str = Field(pattern=SNAKE)
    label: str
    status: Status = Status.active
    sunset: str | None = None


class PicklistDef(BaseModel):
    name: str = Field(pattern=SNAKE)
    description: str
    values: list[PicklistValue]


class ViewDef(BaseModel):
    name: str = Field(pattern=SNAKE)
    object: str
    partition_key: str
    fields: list[str]
    filter: str
    description: str = ""
    status: Status = Status.draft


class NamedQuery(BaseModel):
    name: str = Field(pattern=SNAKE)
    where: str
    order_by: str | None = None


class Grant(BaseModel):
    kind: Literal["object", "view", "edge"]
    target: str
    access: Literal["r", "rw"] = "r"
    delete: bool = False
    fields: list[str] | Literal["*"] = []
    read_only: list[str] = []
    queries: list[NamedQuery] = []
    directions: list[Literal["in", "out"]] = ["in", "out"]


class Route(BaseModel):
    method: Literal["GET", "POST", "PATCH", "PUT", "DELETE"]
    path: str
    uses: str  # "<object>.<query>" or "graph <name>"


class Hosting(BaseModel):
    function_app: str
    resource_group: str
    runtime: str = "python-3.12 / fastapi / functions-v4"
    plan: str = "Flex Consumption"
    managed_identity_client_id: str


class ConsumerDef(BaseModel):
    name: str = Field(pattern=KEBAB)
    type: Literal["ui", "api"]
    label: str
    owner: str
    description: str = Field(min_length=10)
    screen_id: str | None = None
    ru_budget_per_day: int | None = None
    hosting: Hosting
    routes: list[Route] = []
    grants: list[Grant]
    status: Status = Status.draft


class GraphQueryDef(BaseModel):
    name: str
    parameters: list[str]
    depth_cap: int
    latency_target_ms: int
    owner: str
    edges: list[str]
    returns: list[str]
    description: str
    callers: list[str]


# ---- change preview ----
class LintItem(BaseModel):
    severity: Literal["error", "warn", "info"]
    location: str
    message: str


class BreakingItem(BaseModel):
    kind: str
    message: str
    affects: list[str]
    override: str | None = None


class ChangedFile(BaseModel):
    path: str
    status: Literal["A", "M", "D"]
    additions: int
    deletions: int
    patch: str


class ChangeSet(BaseModel):
    branch: str
    base: str
    files: list[ChangedFile]
    lint: list[LintItem]
    breaking: list[BreakingItem]
    reviewers: list[str]
    pr_url: str | None = None


# ---- catalog ----
class Partition(BaseModel):
    key: str
    size_gb: float
    pct: int


class DocsByObject(BaseModel):
    object: str
    docs: int


class ContainerInfo(BaseModel):
    account: str
    database: str
    name: str
    partition_key: str
    throughput: str
    ttl: str
    indexing: dict
    size_gb: float
    document_count: int
    ru_24h: int
    discriminator: str
    documents_by_object: list[DocsByObject]
    top_partitions: list[Partition]


class ConnectionStatus(BaseModel):
    id: str
    title: str
    status: Literal["connected", "error", "not_configured"]
    checked_at: str | None
    message: str
