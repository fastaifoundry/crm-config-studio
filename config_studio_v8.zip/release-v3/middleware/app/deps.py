"""Dependency wiring: one instance of each client for the process lifetime."""
from __future__ import annotations

from dataclasses import dataclass

from azure.identity.aio import DefaultAzureCredential
from fastapi import Request

from .clients.cosmos import Cosmos
from .clients.functions import Functions
from .clients.azure_repos import AzureRepos
from .clients.keyvault import KeyVault
from .clients.monitor import Monitor
from .clients.party_master import PartyMaster
from .db import Database
from .settings import Settings
from .yamlrepo import YamlRepo


@dataclass
class Services:
    settings: Settings
    cred: DefaultAzureCredential
    kv: KeyVault
    git: AzureRepos
    repo: YamlRepo
    cosmos: Cosmos
    monitor: Monitor
    functions: Functions
    party_master: PartyMaster | None
    db: Database

    @classmethod
    async def build(cls, s: Settings) -> "Services":
        cred = DefaultAzureCredential(managed_identity_client_id=s.managed_identity_client_id) if s.managed_identity_client_id else DefaultAzureCredential()
        kv = KeyVault(cred, s.keyvault_url)
        pat = await kv.get(s.ado_pat_secret) if s.ado_auth == "pat" else None
        git = AzureRepos(s.ado_org, s.ado_project, s.ado_repo, cred=None if pat else cred, pat=pat, pipeline_id=s.ado_pipeline_id)
        repo = YamlRepo(git, s.ado_branch, s.ado_schema_path, s.cache_ttl_seconds, prod_readonly=s.environment == "prod")
        cosmos = Cosmos(s.azure_subscription_id, s.cosmos_tag_kv, s.cosmos_discriminator, s.managed_identity_client_id)
        monitor = Monitor(cred, s.azure_subscription_id, s.log_analytics_workspace_id)
        functions = Functions(cred, s.azure_subscription_id, s.functions_tag_kv, s.functions_resource_group, s.app_insights)
        pm = None
        if s.party_master_url:
            cert = None
            try:
                cert = await kv.get(s.party_master_cert_secret)
            except Exception:
                pass
            pm = PartyMaster(s.party_master_url, cert)
        pwd = await kv.get(s.sql_password_secret) if s.sql_auth == "password" else None
        db = Database(s, pwd)  # ops_* tables only (audit, sessions, connection results, snapshots); Alembic-managed
        return cls(s, cred, kv, git, repo, cosmos, monitor, functions, pm, db)

    async def aclose(self) -> None:
        await self.db.dispose()
        await self.cosmos.aclose()
        await self.cred.close()


def services(request: Request) -> Services:
    return request.app.state.services
