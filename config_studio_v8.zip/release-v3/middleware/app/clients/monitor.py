"""Azure Monitor: platform metrics per container and KQL for per-identity RU / partition stats."""
from __future__ import annotations

from datetime import timedelta

from azure.identity.aio import DefaultAzureCredential
from azure.monitor.query.aio import LogsQueryClient, MetricsQueryClient
from azure.monitor.query import MetricAggregationType


class Monitor:
    def __init__(self, cred: DefaultAzureCredential, subscription_id: str, workspace_id: str | None):
        self.cred, self.sub, self.ws = cred, subscription_id, workspace_id
        self.metrics = MetricsQueryClient(cred)
        self.logs = LogsQueryClient(cred) if workspace_id else None

    def _account_id(self, rg: str, account: str) -> str:
        return f"/subscriptions/{self.sub}/resourceGroups/{rg}/providers/Microsoft.DocumentDB/databaseAccounts/{account}"

    async def container_metrics(self, rg: str, account: str, hours: int = 24) -> dict[tuple[str, str], dict]:
        """{(database, container): {ru_24h, data_bytes, index_bytes, document_count}} for one account."""
        res = await self.metrics.query_resource(
            self._account_id(rg, account),
            metric_names=["TotalRequestUnits", "DataUsage", "IndexUsage", "DocumentCount"],
            timespan=timedelta(hours=hours), granularity=timedelta(hours=1),
            aggregations=[MetricAggregationType.TOTAL, MetricAggregationType.MAXIMUM],
            filter="DatabaseName eq '*' and CollectionName eq '*'",
        )
        out: dict[tuple[str, str], dict] = {}
        for m in res.metrics:
            for ts in m.timeseries:
                md = {k.lower(): v for k, v in (ts.metadata_values or {}).items()}
                key = (md.get("databasename", ""), md.get("collectionname", ""))
                slot = out.setdefault(key, {"ru_24h": 0, "data_bytes": 0, "index_bytes": 0, "document_count": 0})
                if m.name == "TotalRequestUnits":
                    slot["ru_24h"] += int(sum((d.total or 0) for d in ts.data))
                else:
                    last = next((d.maximum for d in reversed(ts.data) if d.maximum is not None), 0)
                    slot[{"DataUsage": "data_bytes", "IndexUsage": "index_bytes", "DocumentCount": "document_count"}[m.name]] = int(last)
        return out

    async def ru_by_identity(self, days: int = 7) -> list[dict]:
        """Per calling identity per day. Needs DataPlaneRequests diagnostics in Log Analytics."""
        if not self.logs:
            return []
        q = f"""
        CDBDataPlaneRequests
        | where TimeGenerated > ago({days}d)
        | summarize ru = sum(RequestCharge) by bin(TimeGenerated, 1d), identity = tostring(AadPrincipalId), DatabaseName, CollectionName
        | order by TimeGenerated asc"""
        res = await self.logs.query_workspace(self.ws, q, timespan=timedelta(days=days))
        t = res.tables[0]
        return [dict(zip(t.columns, row)) for row in t.rows]

    async def top_partitions(self, database: str, container: str, n: int = 5) -> list[dict]:
        if not self.logs:
            return []
        q = f"""
        CDBPartitionKeyStatistics
        | where DatabaseName == '{database}' and CollectionName == '{container}'
        | summarize size_kb = max(SizeKb) by PartitionKey
        | top {n} by size_kb desc"""
        res = await self.logs.query_workspace(self.ws, q, timespan=timedelta(days=1))
        t = res.tables[0]
        return [{"key": r[0], "size_gb": round(r[1] * 1024 / 1024**3, 2)} for r in t.rows]

    async def query_shapes(self, days: int = 7) -> list[dict]:
        """Top query shapes by RU, for the Usage screen (QueryRuntimeStatistics diagnostics)."""
        if not self.logs:
            return []
        q = f"""
        CDBQueryRuntimeStatistics
        | where TimeGenerated > ago({days}d)
        | summarize ru = sum(RequestCharge), calls = count() by QueryText, identity = tostring(AadPrincipalId)
        | top 20 by ru desc"""
        res = await self.logs.query_workspace(self.ws, q, timespan=timedelta(days=days))
        t = res.tables[0]
        return [dict(zip(t.columns, row)) for row in t.rows]
