"""Cosmos DB: control plane across every tagged account + read-only data plane for documents-by-_type.

One credential for everything: DefaultAzureCredential (managed identity in Azure, `az login` locally).
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass

from azure.cosmos.aio import CosmosClient
from azure.identity.aio import DefaultAzureCredential
from azure.mgmt.cosmosdb.aio import CosmosDBManagementClient
from azure.mgmt.resourcegraph.aio import ResourceGraphClient
from azure.mgmt.resourcegraph.models import QueryRequest


@dataclass
class Account:
    name: str
    resource_group: str
    endpoint: str
    databases: list[str]


class Cosmos:
    def __init__(self, subscription_id: str, tag: tuple[str, str], discriminator: str, mi_client_id: str | None):
        self.sub, self.tag, self.disc = subscription_id, tag, discriminator
        self.cred = DefaultAzureCredential(managed_identity_client_id=mi_client_id) if mi_client_id else DefaultAzureCredential()
        self.mgmt = CosmosDBManagementClient(self.cred, subscription_id)
        self.graph = ResourceGraphClient(self.cred)

    # ---- discovery ----
    async def accounts(self) -> list[Account]:
        k, v = self.tag
        q = QueryRequest(subscriptions=[self.sub], query=(
            "resources | where type =~ 'microsoft.documentdb/databaseaccounts' "
            f"| where tags['{k}'] =~ '{v}' | project name, resourceGroup, endpoint=properties.documentEndpoint"))
        res = await self.graph.resources(q)
        out: list[Account] = []
        for row in res.data:
            dbs = [d.name async for d in self.mgmt.sql_resources.list_sql_databases(row["resourceGroup"], row["name"])]
            out.append(Account(row["name"], row["resourceGroup"], row["endpoint"], dbs))
        return out

    # ---- control plane ----
    async def containers(self, acc: Account, db: str) -> list[dict]:
        items = []
        async for c in self.mgmt.sql_resources.list_sql_containers(acc.resource_group, acc.name, db):
            r = c.resource
            ttl = "none" if r.default_ttl is None else ("per item" if r.default_ttl == -1 else f"{r.default_ttl // 86400} days")
            try:
                thr = await self.mgmt.sql_resources.get_sql_container_throughput(acc.resource_group, acc.name, db, r.id)
                tr = thr.resource
                throughput = (f"autoscale {tr.autoscale_settings.max_throughput // 10}–{tr.autoscale_settings.max_throughput} RU/s"
                              if tr.autoscale_settings else f"manual {tr.throughput} RU/s")
            except Exception:  # shared database throughput
                throughput = "shared (database)"
            pol = r.indexing_policy
            items.append({
                "account": acc.name, "database": db, "name": r.id,
                "partition_key": ", ".join(r.partition_key.paths or []),
                "throughput": throughput, "ttl": ttl,
                "indexing": {
                    "mode": pol.indexing_mode,
                    "included": [p.path for p in (pol.included_paths or [])],
                    "excluded": [p.path for p in (pol.excluded_paths or [])],
                    "composite": [", ".join(f"{cp.path} {cp.order}" for cp in ci) for ci in (pol.composite_indexes or [])],
                },
            })
        return items

    # ---- data plane (read-only) ----
    async def documents_by_object(self, acc: Account, db: str, container: str) -> list[dict]:
        async with CosmosClient(acc.endpoint, credential=self.cred) as client:
            cont = client.get_database_client(db).get_container_client(container)
            q = f"SELECT c.{self.disc} AS object, COUNT(1) AS docs FROM c GROUP BY c.{self.disc}"
            rows = [r async for r in cont.query_items(q)]
        return sorted(({"object": r["object"] or "(untyped)", "docs": r["docs"]} for r in rows), key=lambda x: -x["docs"])

    async def snapshot(self) -> list[dict]:
        """Everything the Containers screen needs, minus Monitor metrics (merged by the router)."""
        out: list[dict] = []
        for acc in await self.accounts():
            for db in acc.databases:
                conts = await self.containers(acc, db)
                by_type = await asyncio.gather(*(self.documents_by_object(acc, db, c["name"]) for c in conts), return_exceptions=True)
                for c, bt in zip(conts, by_type):
                    c["discriminator"] = self.disc
                    c["documents_by_object"] = bt if isinstance(bt, list) else []
                    out.append(c)
        return out

    async def aclose(self) -> None:
        await self.mgmt.close(); await self.graph.close(); await self.cred.close()
