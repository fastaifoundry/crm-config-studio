"""Azure Repos (Git) client. Same surface YamlRepo needs: tree/read on a ref, branch, push, PR, tags, pipeline runs.

Auth: the middleware's managed identity (Entra token for the Azure DevOps resource) or a PAT from Key Vault.
The identity needs Contribute + Create branch + Contribute to pull requests on the repo, and Read on pipelines.
"""
from __future__ import annotations

import base64
from typing import Any

import httpx
from azure.identity.aio import DefaultAzureCredential

ADO_SCOPE = "499b84ac-1321-427f-aa17-267ca6975798/.default"  # Azure DevOps resource id
API = "7.1"


class AzureRepos:
    def __init__(self, org: str, project: str, repo: str, cred: DefaultAzureCredential | None = None, pat: str | None = None, pipeline_id: int | None = None):
        self.org, self.project, self.repo, self.cred, self.pat, self.pipeline_id = org, project, repo, cred, pat, pipeline_id
        self.base = f"https://dev.azure.com/{org}/{project}/_apis"
        self.http = httpx.AsyncClient(timeout=20)
        self._repo_id: str | None = None

    async def _auth(self) -> dict[str, str]:
        if self.pat:
            return {"Authorization": "Basic " + base64.b64encode(f":{self.pat}".encode()).decode()}
        tok = await self.cred.get_token(ADO_SCOPE)  # type: ignore[union-attr]
        return {"Authorization": f"Bearer {tok.token}"}

    async def _req(self, method: str, path: str, *, params: dict | None = None, json: Any = None, raw: bool = False) -> Any:
        r = await self.http.request(method, f"{self.base}{path}", headers=await self._auth(), params={"api-version": API, **(params or {})}, json=json)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.text if raw else (r.json() if r.content else None)

    async def _rid(self) -> str:
        if not self._repo_id:
            self._repo_id = (await self._req("GET", f"/git/repositories/{self.repo}"))["id"]
        return self._repo_id

    # ---- read ----
    async def tree(self, ref: str, prefix: str) -> list[dict]:
        rid = await self._rid()
        vt = "tag" if ref.startswith("v") or ref[0].isdigit() else "branch"
        data = await self._req("GET", f"/git/repositories/{rid}/items", params={
            "scopePath": "/" + prefix.strip("/"), "recursionLevel": "Full", "versionDescriptor.version": ref, "versionDescriptor.versionType": vt})
        return [{"path": i["path"].lstrip("/"), "sha": i["objectId"]} for i in (data or {}).get("value", []) if not i.get("isFolder")]

    async def read(self, path: str, ref: str) -> tuple[str, str] | None:
        rid = await self._rid()
        vt = "tag" if ref.startswith("v") or ref[0].isdigit() else "branch"
        text = await self._req("GET", f"/git/repositories/{rid}/items", raw=True, params={
            "path": "/" + path, "versionDescriptor.version": ref, "versionDescriptor.versionType": vt, "includeContent": "true"})
        if text is None:
            return None
        meta = await self._req("GET", f"/git/repositories/{rid}/items", params={"path": "/" + path, "versionDescriptor.version": ref, "versionDescriptor.versionType": vt})
        return text, meta["objectId"]

    async def branch_sha(self, branch: str) -> str | None:
        rid = await self._rid()
        data = await self._req("GET", f"/git/repositories/{rid}/refs", params={"filter": f"heads/{branch}"})
        v = (data or {}).get("value", [])
        return v[0]["objectId"] if v else None

    async def latest_release_tag(self) -> str | None:
        rid = await self._rid()
        data = await self._req("GET", f"/git/repositories/{rid}/refs", params={"filter": "tags/", "$top": 200})
        tags = sorted((t["name"].removeprefix("refs/tags/") for t in (data or {}).get("value", [])), reverse=True)
        return tags[0] if tags else None

    async def releases(self, n: int = 10) -> list[dict]:
        rid = await self._rid()
        data = await self._req("GET", f"/git/repositories/{rid}/refs", params={"filter": "tags/", "$top": 200})
        tags = sorted(((t["name"].removeprefix("refs/tags/"), t["objectId"]) for t in (data or {}).get("value", [])), reverse=True)[:n]
        out = []
        for name, oid in tags:
            c = await self._req("GET", f"/git/repositories/{rid}/commits/{oid}")
            out.append({"id": name, "date": c["committer"]["date"] if c else None, "summary": (c or {}).get("comment", "").split("\n")[0],
                        "url": f"https://dev.azure.com/{self.org}/{self.project}/_git/{self.repo}?version=GT{name}"})
        return out

    async def compare(self, base: str, head: str) -> dict:
        """Shape compatible with YamlRepo.changeset: {'files': [{filename, status, additions, deletions, patch}]}."""
        rid = await self._rid()
        data = await self._req("GET", f"/git/repositories/{rid}/diffs/commits", params={
            "baseVersion": base, "baseVersionType": "branch", "targetVersion": head, "targetVersionType": "branch", "$top": 500})
        files = []
        for ch in (data or {}).get("changes", []):
            if ch["item"].get("isFolder"):
                continue
            status = {"add": "added", "edit": "modified", "delete": "removed", "rename": "renamed"}.get(ch["changeType"].split(",")[0], "modified")
            path = ch["item"]["path"].lstrip("/")
            before = (await self.read(path, base) or ("", ""))[0] if status != "added" else ""
            after = (await self.read(path, head) or ("", ""))[0] if status != "removed" else ""
            patch, adds, dels = _unified(before, after)
            files.append({"filename": path, "status": status, "additions": adds, "deletions": dels, "patch": patch})
        return {"files": files}

    async def check_runs(self, ref: str) -> list[dict]:
        """Latest pipeline runs for the branch, in the GitHub check-run shape YamlRepo expects."""
        if not self.pipeline_id:
            return []
        data = await self._req("GET", f"/pipelines/{self.pipeline_id}/runs", params={"$top": 20})
        out = []
        for run in (data or {}).get("value", []):
            if run.get("resources", {}).get("repositories", {}).get("self", {}).get("refName") != f"refs/heads/{ref}":
                continue
            concl = {"succeeded": "success", "failed": "failure", "canceled": "cancelled"}.get(run.get("result"), run.get("state"))
            out.append({"name": run["name"], "conclusion": concl, "output": {"title": run.get("result") or run.get("state")}, "url": run["_links"]["web"]["href"]})
        return out[:1]

    # ---- write (always to a branch) ----
    async def ensure_branch(self, branch: str, from_branch: str) -> str:
        sha = await self.branch_sha(branch)
        if sha:
            return sha
        base = await self.branch_sha(from_branch)
        rid = await self._rid()
        await self._req("POST", f"/git/repositories/{rid}/refs", json=[{"name": f"refs/heads/{branch}", "oldObjectId": "0" * 40, "newObjectId": base}])
        return base  # type: ignore[return-value]

    async def _push(self, branch: str, changes: list[dict], message: str) -> None:
        rid = await self._rid()
        old = await self.branch_sha(branch)
        await self._req("POST", f"/git/repositories/{rid}/pushes", json={
            "refUpdates": [{"name": f"refs/heads/{branch}", "oldObjectId": old}],
            "commits": [{"comment": message, "changes": changes}]})

    async def write(self, path: str, text: str, message: str, branch: str) -> None:
        exists = await self.read(path, branch)
        await self._push(branch, [{"changeType": "edit" if exists else "add", "item": {"path": "/" + path},
                                   "newContent": {"content": text, "contentType": "rawtext"}}], message)

    async def delete(self, path: str, message: str, branch: str) -> None:
        if await self.read(path, branch):
            await self._push(branch, [{"changeType": "delete", "item": {"path": "/" + path}}], message)

    async def open_pr(self, branch: str, base: str, title: str, body: str, reviewers: list[str]) -> dict:
        rid = await self._rid()
        pr = await self._req("POST", f"/git/repositories/{rid}/pullrequests", json={
            "sourceRefName": f"refs/heads/{branch}", "targetRefName": f"refs/heads/{base}", "title": title, "description": body,
            "reviewers": [{"id": await self._group_id(r)} for r in reviewers if r.startswith("@")] if reviewers else []})
        pr["html_url"] = f"https://dev.azure.com/{self.org}/{self.project}/_git/{self.repo}/pullrequest/{pr['pullRequestId']}"
        return pr

    async def _group_id(self, handle: str) -> str:
        """Map '@crm/coverage-platform' → Azure DevOps group descriptor id. Groups are named 'crm-coverage-platform' in the project."""
        name = handle.lstrip("@").replace("/", "-")
        data = await self._req("GET", f"https://vssps.dev.azure.com/{self.org}/_apis/identities".replace(self.base, ""), params={"searchFilter": "General", "filterValue": name})
        v = (data or {}).get("value", [])
        return v[0]["id"] if v else ""

    async def delete_branch(self, branch: str) -> None:
        old = await self.branch_sha(branch)
        if old:
            rid = await self._rid()
            await self._req("POST", f"/git/repositories/{rid}/refs", json=[{"name": f"refs/heads/{branch}", "oldObjectId": old, "newObjectId": "0" * 40}])


def _unified(before: str, after: str) -> tuple[str, int, int]:
    import difflib
    lines = list(difflib.unified_diff(before.splitlines(), after.splitlines(), lineterm="", n=2))
    adds = sum(1 for l in lines if l.startswith("+") and not l.startswith("+++"))
    dels = sum(1 for l in lines if l.startswith("-") and not l.startswith("---"))
    return "\n".join(lines[2:]), adds, dels
