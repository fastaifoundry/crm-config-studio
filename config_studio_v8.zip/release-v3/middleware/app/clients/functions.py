"""Azure Functions: tagged function apps (the consumers), their user-assigned identities, App Insights route stats."""
from __future__ import annotations

from datetime import timedelta

from azure.identity.aio import DefaultAzureCredential
from azure.mgmt.resourcegraph.aio import ResourceGraphClient
from azure.mgmt.resourcegraph.models import QueryRequest
from azure.monitor.query.aio import LogsQueryClient


class Functions:
    def __init__(self, cred: DefaultAzureCredential, subscription_id: str, tag: tuple[str, str],
                 resource_group: str, app_insights: list[str]):
        self.cred, self.sub, self.tag, self.rg, self.ai = cred, subscription_id, tag, resource_group, app_insights
        self.graph = ResourceGraphClient(cred)
        self.logs = LogsQueryClient(cred)

    async def apps(self) -> list[dict]:
        """Every function app carrying the tag, with plan, runtime and user-assigned identity client id."""
        k, v = self.tag
        q = QueryRequest(subscriptions=[self.sub], query=f"""
        resources
        | where type =~ 'microsoft.web/sites' and kind contains 'functionapp'
        | where tags['{k}'] =~ '{v}'
        | extend ua = identity.userAssignedIdentities
        | mv-expand ua
        | project name, resourceGroup, runtime = tostring(properties.siteConfig.linuxFxVersion),
                  plan = tostring(properties.sku), mi_client_id = tostring(ua.clientId),
                  app_insights = tostring(tags['app-insights'])""")
        res = await self.graph.resources(q)
        return [dict(r) for r in res.data]

    def _ai_resource_id(self, name: str) -> str:
        return f"/subscriptions/{self.sub}/resourceGroups/{self.rg}/providers/Microsoft.Insights/components/{name}"

    async def routes(self, function_app: str, days: int = 7) -> list[dict]:
        """Observed FastAPI routes for one app: calls, p95 latency, failures. Searches every configured App Insights."""
        q = f"""
        requests
        | where cloud_RoleName =~ '{function_app}' and timestamp > ago({days}d)
        | extend route = tostring(customDimensions['http.route'])
        | where isnotempty(route)
        | summarize calls = count(), p95_ms = percentile(duration, 95), failed = countif(success == false)
              by method = tostring(customDimensions['http.method']), route
        | order by calls desc"""
        out: list[dict] = []
        for ai in self.ai:
            try:
                res = await self.logs.query_resource(self._ai_resource_id(ai), q, timespan=timedelta(days=days))
            except Exception:
                continue
            for t in res.tables:
                out += [dict(zip(t.columns, row)) | {"app_insights": ai} for row in t.rows]
        return out
