"""Key Vault secrets (GitHub App private key, party-master client certificate)."""
from __future__ import annotations

from azure.identity.aio import DefaultAzureCredential
from azure.keyvault.secrets.aio import SecretClient


class KeyVault:
    def __init__(self, cred: DefaultAzureCredential, url: str):
        self.client = SecretClient(vault_url=url, credential=cred)

    async def get(self, name: str) -> str:
        return (await self.client.get_secret(name)).value or ""

    async def ping(self) -> int:
        n = 0
        async for _ in self.client.list_properties_of_secrets():
            n += 1
        return n
