"""Party master: read-only schema pull for party / person / organisation and master-managed edges."""
from __future__ import annotations

import ssl
import tempfile

import httpx


class PartyMaster:
    def __init__(self, base_url: str, client_cert_pem: str | None = None):
        ctx = None
        if client_cert_pem:
            f = tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False)
            f.write(client_cert_pem); f.close()
            ctx = ssl.create_default_context(); ctx.load_cert_chain(f.name)
        self.http = httpx.AsyncClient(base_url=base_url, timeout=15, verify=ctx or True)

    async def schemas(self) -> dict:
        """{ 'party': {...}, 'person': {...}, 'organisation': {...}, 'edges': [...] } in the master's own format."""
        r = await self.http.get("/schema")
        r.raise_for_status()
        return r.json()

    async def health(self) -> dict:
        r = await self.http.get("/health")
        r.raise_for_status()
        return r.json()
