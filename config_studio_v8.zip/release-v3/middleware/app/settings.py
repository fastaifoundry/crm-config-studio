"""Configuration. Mirrors the Settings screen: every card there is a block here."""
from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # which environment this deployment serves; prod = catalog only
    environment: str = "dev"                  # dev | test | acc | prod

    # identity provider
    entra_tenant_id: str
    entra_audience: str
    entra_groups_claim: str = "groups"
    entra_team_attr: str = "extension_teamCode"
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:5173"])

    # schema repository (Azure Repos)
    ado_org: str
    ado_project: str
    ado_repo: str
    ado_branch: str = "main"
    ado_schema_path: str = "schema/"
    ado_auth: str = "mi"                       # mi | pat
    ado_pat_secret: str = "ado-pat"            # Key Vault secret name, pat auth only
    ado_pipeline_id: int | None = None         # schema pipeline (lint + deploy) for run status on branches

    # azure
    azure_subscription_id: str
    managed_identity_client_id: str | None = None
    cosmos_tag: str = "crm-data=true"
    cosmos_discriminator: str = "_type"
    functions_tag: str = "crm-consumer=true"
    functions_resource_group: str
    app_insights: list[str] = Field(default_factory=list)
    log_analytics_workspace_id: str | None = None
    monitor_refresh_minutes: int = 15
    keyvault_url: str

    # azure sql — the middleware's own store (PLACEHOLDER values; see app/db.py)
    sql_server: str = "sql-crm-config-prod.database.windows.net"
    sql_database: str = "crm_config_studio"
    sql_auth: str = "mi"                       # mi | entra | password
    sql_user: str | None = None                # password auth only
    sql_password_secret: str = "sql-studio-password"   # Key Vault secret name, password auth only
    sql_odbc_driver: str = "ODBC Driver 18 for SQL Server"
    sql_schema: str = "dbo"

    # party master
    party_master_url: str | None = None
    party_master_cert_secret: str = "party-master-cert"

    cache_ttl_seconds: int = 60

    @property
    def cosmos_tag_kv(self) -> tuple[str, str]:
        k, _, v = self.cosmos_tag.partition("=")
        return k, v or "true"

    @property
    def functions_tag_kv(self) -> tuple[str, str]:
        k, _, v = self.functions_tag.partition("=")
        return k, v or "true"


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
