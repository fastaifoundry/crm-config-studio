"""FastAPI app. `uvicorn app.main:app` locally; wrapped by function_app.py on Azure Functions."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .deps import Services
from .routers import access, catalog, changes, connections, consumers, conventions, lineage, schema
from .settings import get_settings

log = logging.getLogger("studio")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.services = await Services.build(get_settings())
    yield
    await app.state.services.aclose()


app = FastAPI(title="CRM Config Studio middleware", version="0.1.0", lifespan=lifespan, docs_url="/docs")
app.add_middleware(CORSMiddleware, allow_origins=get_settings().cors_origins, allow_credentials=False,
                   allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type", "X-Studio-Refresh"])

for r in (access.router, schema.router, conventions.router, consumers.router, changes.router, catalog.router, connections.router, connections.settings_router, lineage.router):
    app.include_router(r)


@app.get("/health", include_in_schema=False)
async def health():
    return {"ok": True}


@app.exception_handler(httpx.HTTPStatusError)
async def upstream_error(_: Request, e: httpx.HTTPStatusError):
    log.warning("upstream %s %s → %s", e.request.method, e.request.url, e.response.status_code)
    return JSONResponse(502, {"error": {"code": "upstream", "message": f"{e.request.url.host} returned {e.response.status_code}",
                                        "detail": e.response.text[:500]}})


@app.exception_handler(Exception)
async def unhandled(_: Request, e: Exception):
    log.exception("unhandled")
    return JSONResponse(500, {"error": {"code": type(e).__name__, "message": str(e)[:300]}})
