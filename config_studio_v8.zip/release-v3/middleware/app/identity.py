"""Per-user Azure Repos credentials and the audit trail.

Reads use the studio's managed identity. Every write to Azure Repos uses the *caller's* PAT, so commits, branches and
pull requests are authored by the person, not by the service. PATs live in Key Vault as `ado-pat-<oid>`; the
middleware only ever holds one in memory for the duration of a request.
"""
from __future__ import annotations

from datetime import UTC, datetime

from fastapi import Depends, HTTPException, Request, status

from .auth import User, current_user
from .clients.azure_repos import AzureRepos
from .db.repo import OpsRepo
from .deps import Services, services
from .yamlrepo import YamlRepo


def _secret_name(user: User) -> str:
    return f"ado-pat-{user.oid}"


async def user_pat(user: User, svc: Services) -> str | None:
    try:
        return await svc.kv.get(_secret_name(user))
    except Exception:
        return None


async def store_pat(user: User, svc: Services, pat: str, expires: str) -> None:
    from datetime import date
    exp = date.fromisoformat(expires)
    await svc.kv.client.set_secret(_secret_name(user), pat, expires_on=datetime(exp.year, exp.month, exp.day, tzinfo=UTC),
                                   tags={"upn": user.upn, "scopes": "vso.code_write vso.code_status", "org": svc.settings.ado_org})


async def delete_pat(user: User, svc: Services) -> None:
    poller = await svc.kv.client.delete_secret(_secret_name(user))
    await poller.wait()


async def pat_status(user: User, svc: Services) -> dict:
    try:
        props = (await svc.kv.client.get_secret(_secret_name(user))).properties
        return {"present": True, "expires": props.expires_on.date().isoformat() if props.expires_on else None, "added": props.created_on.date().isoformat() if props.created_on else None}
    except Exception:
        return {"present": False, "expires": None, "added": None}


async def user_repo(user: User = Depends(current_user), svc: Services = Depends(services)) -> YamlRepo:
    """A YamlRepo whose writes go through the caller's PAT. Reads still go through the shared client (cached)."""
    pat = await user_pat(user, svc)
    if not pat:
        raise HTTPException(status.HTTP_428_PRECONDITION_REQUIRED, "add your Azure Repos PAT first (PUT /api/me/pat); commits must carry your name")
    s = svc.settings
    git = AzureRepos(s.ado_org, s.ado_project, s.ado_repo, pat=pat, pipeline_id=s.ado_pipeline_id)
    repo = YamlRepo(git, s.ado_branch, s.ado_schema_path, s.cache_ttl_seconds, prod_readonly=s.environment == "prod")
    repo.cache = svc.repo.cache  # share the read cache so a write invalidates everyone's view
    return repo


async def audit(svc: Services, user: User, action: str, target: str, detail: dict | None = None, branch: str | None = None) -> None:
    """One row per write. Called by every mutating route; failures here never fail the user's request."""
    try:
        async with svc.db.session() as s:
            ops = OpsRepo(s)
            if branch:
                await ops.open_session(branch, user.upn)
            await ops.audit(user.upn, action, target, {"env": svc.settings.environment, **(detail or {})}, branch)
    except Exception:
        import logging
        logging.getLogger("studio").exception("audit write failed")
