"""SQLAlchemy 2.0 ORM models. Alembic manages the schema. One database per environment.

Two groups:
- cfg_*  — the configuration *as deployed to this environment*, written only by the pipeline (app/deploy/sync_to_sql.py)
           after a successful deploy. Catalog mode reads it. In production this always equals main; in dev it may be a
           studio branch. Git stays the source of truth for Design mode; these rows are the deployed snapshot, not a mirror.
- ops_*  — the middleware's own records: deployments, audit, change sessions, connection results, cached Azure pulls.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, DateTime, Integer, String, Text, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    type_annotation_map = {list: JSON, dict: JSON}


class Deployed:
    """Common columns for deployed config rows. `doc` is the full YAML document; indexed columns are for filtering."""
    doc: Mapped[dict] = mapped_column(JSON)
    deployed_ref: Mapped[str | None] = mapped_column(String(120))
    deployed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.sysutcdatetime())


class CfgObject(Base, Deployed):
    __tablename__ = "cfg_object"
    api_name: Mapped[str] = mapped_column(String(40), primary_key=True)
    kind: Mapped[str] = mapped_column(String(16))
    container: Mapped[str] = mapped_column(String(40))
    owner: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(12))
    managed_by: Mapped[str] = mapped_column(String(16))


class CfgPicklist(Base, Deployed):
    __tablename__ = "cfg_picklist"
    name: Mapped[str] = mapped_column(String(40), primary_key=True)


class CfgEdge(Base, Deployed):
    __tablename__ = "cfg_edge"
    name: Mapped[str] = mapped_column(String(40), primary_key=True)


class CfgView(Base, Deployed):
    __tablename__ = "cfg_view"
    name: Mapped[str] = mapped_column(String(40), primary_key=True)
    object_api: Mapped[str] = mapped_column(String(40))


class CfgGraphQuery(Base, Deployed):
    __tablename__ = "cfg_graph_query"
    name: Mapped[str] = mapped_column(String(60), primary_key=True)


class CfgConsumer(Base, Deployed):
    __tablename__ = "cfg_consumer"
    name: Mapped[str] = mapped_column(String(60), primary_key=True)
    type: Mapped[str] = mapped_column(String(4))
    owner: Mapped[str] = mapped_column(String(80))
    function_app: Mapped[str] = mapped_column(String(80))
    managed_identity_client_id: Mapped[str] = mapped_column(String(36), unique=True)


class Deployment(Base):
    __tablename__ = "ops_deployment"
    id: Mapped[int] = mapped_column(primary_key=True)
    environment: Mapped[str] = mapped_column(String(8))                  # dev | test | acc | prod
    ref: Mapped[str] = mapped_column(String(120))                        # branch or tag deployed
    commit: Mapped[str] = mapped_column(String(40))
    pipeline_run: Mapped[str | None] = mapped_column(String(40))
    deployed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.sysutcdatetime())
    objects: Mapped[int] = mapped_column(Integer, default=0)
    consumers: Mapped[int] = mapped_column(Integer, default=0)


class Connection(Base):
    __tablename__ = "ops_connection"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)       # repo | cosmos | monitor | functions | keyvault | sql | idp | pipelines | party_master
    config: Mapped[dict] = mapped_column(JSON)                            # non-secret; secrets referenced by Key Vault name
    status: Mapped[str | None] = mapped_column(String(16))
    message: Mapped[str | None] = mapped_column(Text)
    checked_at: Mapped[datetime | None] = mapped_column(DateTime)
    updated_by: Mapped[str | None] = mapped_column(String(120))
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.sysutcdatetime(), onupdate=func.sysutcdatetime())


class ChangeSession(Base):
    __tablename__ = "ops_change_session"
    branch: Mapped[str] = mapped_column(String(120), primary_key=True)  # studio/<user>/<date>
    upn: Mapped[str] = mapped_column(String(120))
    opened_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.sysutcdatetime())
    pr_url: Mapped[str | None] = mapped_column(String(300))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime)


class Audit(Base):
    __tablename__ = "ops_audit"
    id: Mapped[int] = mapped_column(primary_key=True)
    at: Mapped[datetime] = mapped_column(DateTime, server_default=func.sysutcdatetime())
    upn: Mapped[str] = mapped_column(String(120))
    action: Mapped[str] = mapped_column(String(40))                     # object.create | field.deprecate | consumer.register | pr.open | connection.test …
    target: Mapped[str | None] = mapped_column(String(200))
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    branch: Mapped[str | None] = mapped_column(String(120))
    commit: Mapped[str | None] = mapped_column(String(40))          # Azure Repos commit id when the action produced one
    source: Mapped[str] = mapped_column(String(20), default="studio")  # studio | pipeline | azure-devops


class CatalogSnapshot(Base):
    __tablename__ = "ops_catalog_snapshot"
    kind: Mapped[str] = mapped_column(String(20), primary_key=True)      # containers | usage | routes
    as_of: Mapped[datetime] = mapped_column(DateTime, primary_key=True)
    payload: Mapped[dict] = mapped_column(JSON)


class Setting(Base):
    """Environment parameters (this database serves exactly one environment). Changed from the Settings screen without a release."""
    __tablename__ = "ops_setting"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)                      # {"v": <json value>}
    updated_by: Mapped[str | None] = mapped_column(String(120))
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.sysutcdatetime(), onupdate=func.sysutcdatetime())
