"""Async engine + session factory for Azure SQL. Same managed identity as everything else.

    async with svc.db.session() as s:
        obj = await s.get(ConfigObject, "coverage")
"""
from __future__ import annotations

import struct
import urllib.parse
from contextlib import asynccontextmanager

from azure.identity import DefaultAzureCredential
from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine

from ..settings import Settings

SQL_COPT_SS_ACCESS_TOKEN = 1256  # msodbcsql.h
TOKEN_SCOPE = "https://database.windows.net/.default"


def odbc_string(s: Settings, password: str | None = None) -> str:
    base = (f"Driver={{{s.sql_odbc_driver}}};Server=tcp:{s.sql_server},1433;Database={s.sql_database};"
            "Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;")
    if s.sql_auth == "password":  # PLACEHOLDER: only if SQL logins are unavoidable; password comes from Key Vault
        return base + f"Uid={s.sql_user};Pwd={password or ''};"
    return base


class Database:
    def __init__(self, s: Settings, password: str | None = None):
        url = "mssql+aioodbc:///?odbc_connect=" + urllib.parse.quote_plus(odbc_string(s, password))
        self.engine: AsyncEngine = create_async_engine(url, pool_pre_ping=True, pool_size=5, max_overflow=10)
        self.sessions = async_sessionmaker(self.engine, expire_on_commit=False, class_=AsyncSession)
        if s.sql_auth != "password":
            cred = DefaultAzureCredential(managed_identity_client_id=s.managed_identity_client_id) if s.managed_identity_client_id else DefaultAzureCredential()

            @event.listens_for(self.engine.sync_engine, "do_connect")
            def _inject_token(dialect, conn_rec, cargs, cparams):
                tok = cred.get_token(TOKEN_SCOPE).token.encode("utf-16-le")
                cparams["attrs_before"] = {SQL_COPT_SS_ACCESS_TOKEN: struct.pack(f"<I{len(tok)}s", len(tok), tok)}

    @asynccontextmanager
    async def session(self):
        async with self.sessions() as s:
            try:
                yield s
                await s.commit()
            except Exception:
                await s.rollback()
                raise

    async def ping(self) -> str:
        async with self.engine.connect() as conn:
            row = (await conn.execute(text(
                "SELECT DB_NAME(), SUSER_SNAME(), (SELECT COUNT(*) FROM sys.tables WHERE name LIKE 'cfg_%' OR name LIKE 'ops_%'), "
                "(SELECT TOP 1 version_num FROM alembic_version)"))).one()
            return f"{row[0]} as {row[1]} · {row[2]} tables · alembic {row[3]}"

    async def dispose(self) -> None:
        await self.engine.dispose()
