"""OpsRepo: the few writes/reads the routers need against the SQL store."""
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from . import models as m


class OpsRepo:
    def __init__(self, s: AsyncSession):
        self.s = s

    async def audit(self, upn: str, action: str, target: str, detail: dict | None = None, branch: str | None = None, commit: str | None = None, source: str = "studio") -> None:
        self.s.add(m.Audit(upn=upn, action=action, target=target, detail=detail or {}, branch=branch, commit=commit, source=source))

    async def audit_rows(self, q: str | None = None, upn: str | None = None, limit: int = 200) -> list[m.Audit]:
        stmt = select(m.Audit).order_by(m.Audit.at.desc()).limit(limit)
        if upn:
            stmt = stmt.where(m.Audit.upn == upn)
        if q:
            like = f"%{q}%"
            stmt = stmt.where((m.Audit.target.ilike(like)) | (m.Audit.action.ilike(like)) | (m.Audit.upn.ilike(like)) | (m.Audit.branch.ilike(like)))
        return list((await self.s.scalars(stmt)).all())

    async def open_session(self, branch: str, upn: str) -> None:
        if not await self.s.get(m.ChangeSession, branch):
            self.s.add(m.ChangeSession(branch=branch, upn=upn))

    async def close_session(self, branch: str, pr_url: str | None) -> None:
        row = await self.s.get(m.ChangeSession, branch)
        if row:
            row.pr_url, row.closed_at = pr_url, datetime.now(UTC)

    async def record_connection(self, conn_id: str, config: dict, status: str, message: str, upn: str) -> None:
        row = await self.s.get(m.Connection, conn_id) or m.Connection(id=conn_id)
        row.config, row.status, row.message, row.checked_at, row.updated_by = config, status, message, datetime.now(UTC), upn
        self.s.add(row)

    async def connections(self) -> list[m.Connection]:
        return list((await self.s.scalars(select(m.Connection))).all())

    # ---- deployed state (written by the pipeline, read by Catalog) ----
    async def latest_deployment(self) -> m.Deployment | None:
        return await self.s.scalar(select(m.Deployment).order_by(m.Deployment.deployed_at.desc()).limit(1))

    async def deployed(self, model) -> list:
        return list((await self.s.scalars(select(model))).all())

    async def snapshot(self, kind: str, payload: dict) -> None:
        self.s.add(m.CatalogSnapshot(kind=kind, as_of=datetime.now(UTC), payload=payload))

    async def latest_snapshot(self, kind: str) -> m.CatalogSnapshot | None:
        return await self.s.scalar(select(m.CatalogSnapshot).where(m.CatalogSnapshot.kind == kind).order_by(m.CatalogSnapshot.as_of.desc()).limit(1))

    # ---- environment parameters ----
    async def settings(self) -> dict:
        rows = list((await self.s.scalars(select(m.Setting))).all())
        return {r.key: r.value.get("v") for r in rows}

    async def set_setting(self, key: str, value, upn: str) -> None:
        row = await self.s.get(m.Setting, key) or m.Setting(key=key)
        row.value, row.updated_by = {"v": value}, upn
        self.s.add(row)

    async def connection_config(self, conn_id: str) -> dict:
        row = await self.s.get(m.Connection, conn_id)
        return (row.config if row else None) or {}
