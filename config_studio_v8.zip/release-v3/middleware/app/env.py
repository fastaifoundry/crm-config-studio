"""Environments. One middleware deployment per environment (dev / test / acc / prod), each with its own Azure SQL,
Cosmos accounts, function apps and App Insights. Azure Repos, Azure Pipelines, Entra and Key Vault are shared.

Production is catalog only: every write route is rejected with 403 there, and Design mode reads are answered from
main (never a studio branch).
"""
from __future__ import annotations

from enum import StrEnum

from fastapi import Depends, HTTPException, status

from .settings import Settings, get_settings


class Env(StrEnum):
    dev = "dev"
    test = "test"
    acc = "acc"
    prod = "prod"


def current_env(s: Settings = Depends(get_settings)) -> Env:
    return Env(s.environment)


def require_writable_env(env: Env = Depends(current_env)) -> Env:
    if env == Env.prod:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "production is catalog only; design in dev, test or acceptance and promote through a pull request")
    return env
