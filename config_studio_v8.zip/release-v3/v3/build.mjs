// Assemble the single-file app from src/. Usage: node build.mjs  → ../CRM Config Studio V3.dc.html (or --out <path>)
import { readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
const here = dirname(fileURLToPath(import.meta.url))
const read = (p) => readFileSync(join(here, p), 'utf8')
const dir = (p) => readdirSync(join(here, p)).filter((f) => !f.startsWith('.')).sort().map((f) => read(join(p, f)))
const out = process.argv.includes('--out') ? process.argv[process.argv.indexOf('--out') + 1] : join(here, '..', 'CRM Config Studio V3.dc.html')
const html = read('src/00-head.html') + dir('src/template').join('\n') + read('src/50-dc-script-open.html') + dir('src/logic').join('\n') + read('src/99-tail.html')
writeFileSync(out, html)
console.log('built', out, html.length, 'bytes')
