    /* Right rail */
    let railL=null, railTitle='YAML', railPath='';
    if(S.screen==='object'){ railL=this.objYaml(o); railPath=`objects/${o.api}.yaml`; }
    else if(S.screen==='picklists'){ railL=this.pickYaml(S.pickId); railPath=`picklists/${S.pickId}.yaml`; }
    else if(S.screen==='edges'){ railL=this.edgeYaml(edge); railPath=`edges/${edge.name}.yaml`; }
    else if(S.screen==='consumer'){ railL=this.consYaml(cs); railPath=`consumers/${cs.type}/${cs.name.slice(cs.type.length+1)}.yaml`; }
    else if(S.screen==='register'&&S.cf){ railL=this.consYaml(Object.assign({},cf,{name:cf.type+'.'+(cf.name||'<name>'),clientId:cf.clientId||'<client id>',budget:cf.budget?Number(cf.budget):0,screenId:cf.type==='ui'?cf.screenId:''})); railTitle='Preview'; railPath=`consumers/${cf.type}/${cf.name||'<name>'}.yaml`; }
    const railRelevant=!!railL&&(isDesign||['object','consumer'].includes(S.screen));
    V.railOpen=railRelevant&&S.railOpen; V.railClosed=railRelevant&&!S.railOpen; V.toggleRail=()=>this.setState({railOpen:!S.railOpen}); V.railTitle=railTitle; V.railPath=railPath; V.copyYaml=()=>this.toast('YAML copied');
    V.yamlLines=railL?this.yamlLines(railL):[];
    const railC=S.screen==='consumer'?[cs]:objCons; const railRu=[0,1,2,3,4,5,6].map(i=>railC.reduce((a,c)=>a+c.ru[i],0)); const railMax=Math.max(1,...railRu);
    V.railRu=railRu.map(r=>({h:Math.round(r/railMax*100)+'%'})); V.railRuTotal=this.fmt(railRu.reduce((a,b)=>a+b,0)*1000); V.railConsumers=railC.map(c=>({name:c.name,ruLabel:this.fmt(this.ruTotal(c)),onClick:()=>this.go('consumer',{consId:c.name,consTab:'usage'})})); V.railLastSeen=railC.length?railC[0].lastSeen+' · '+railC[0].name:'never';
