  /* ---------- derived ---------- */
  allObjects(){ return this.D.OBJECTS.concat(this.state.newObjects).filter(o=>!this.isRemoved('object',o.api)).map(o=>Object.assign({},o,this.ov('object',o.api))); }
  allConsumers(){ return this.D.CONSUMERS.concat(this.state.newConsumers).filter(c=>!this.isRemoved('consumer',c.name)).map(c=>Object.assign({},c,this.ov('consumer',c.name))); }
  obj(api){ return this.allObjects().find(o=>o.api===(api||this.state.objId)); }
  fieldsOf(o){ const add=this.state.added[o.api]||[]; const dep=this.state.deprecated[o.api]||{}; const base=o.extends?this.allObjects().find(b=>b.api===o.extends):null; const inh=base&&base.kind==='abstract'?base.fields.map(x=>Object.assign({},x,{_inherited:base.api})):[]; return inh.concat(o.fields.map(f=>dep[f.name]?Object.assign({},f,{status:'deprecated',sunset:dep[f.name].sunset,_mod:true}):f)).concat(add.map(a=>Object.assign({},a,{_new:true}))); }
  consumersOf(api,field){ return this.allConsumers().filter(c=>c.grants.some(g=>g.kind==='object'&&g.target===api&&(!field||g.fields==='*'||g.fields.includes(field)))); }
  exposureOf(f){ return Object.assign({ui:'edit',api:'edit'},f.exposure||{}); }
  exposureChip(level){ return {edit:{bg:'var(--grbg)',fg:'var(--gr)',bd:'var(--gr)',label:'edit'},view:{bg:'var(--acbg)',fg:'var(--actx)',bd:'var(--bd2)',label:'view'},hidden:{bg:'var(--sf3)',fg:'var(--tx3)',bd:'var(--bd2)',label:'locked'}}[level]||{bg:'var(--sf3)',fg:'var(--tx3)',bd:'var(--bd2)',label:level}; }
  exposureCells(f){ const e=this.exposureOf(f); return [['UI',e.ui],['API',e.api]].map(([ch,lv])=>Object.assign({ch},this.exposureChip(lv),{title:`${ch}: ${lv==='edit'?'viewable and editable':lv==='view'?'viewable, not editable':'not exposed'}`})); }
  graphList(){ return this.D.GRAPH.concat(this.state.newGraph||[]).filter(g=>!this.isRemoved('graph',g.name)).map(g=>Object.assign({},g,this.ov('graph',g.name))); }
  typeDetail(f){ if(f.type==='string')return `string(${f.len||255})`; if(f.type==='decimal')return `decimal(${f.prec||18},${f.scale||2})`; if(f.type==='picklist'||f.type==='multipicklist')return `${f.type}(${f.picklist})`; if(f.type==='lookup')return `lookup(${f.target})`; return f.type; }
  chip(status){ const C={active:{bg:'var(--grbg)',fg:'var(--gr)',bd:'var(--gr)'},draft:{bg:'var(--sf3)',fg:'var(--tx2)',bd:'var(--bd2)'},deprecated:{bg:'var(--ambg)',fg:'var(--am)',bd:'var(--am)'},blocked:{bg:'var(--rdbg)',fg:'var(--rd)',bd:'var(--rd)'}}; return C[status]||C.draft; }
  pii(p){ return {none:{bg:'var(--sf3)',fg:'var(--tx2)',bd:'var(--bd2)'},personal:{bg:'var(--ambg)',fg:'var(--am)',bd:'var(--am)'},sensitive:{bg:'var(--rdbg)',fg:'var(--rd)',bd:'var(--rd)'}}[p]||{bg:'var(--sf3)',fg:'var(--tx2)',bd:'var(--bd2)'}; }
  fmt(n){ return n>=1e6?(n/1e6).toFixed(1)+'M':n>=1e3?Math.round(n/1e3)+'k':String(n); }
  ruTotal(c){ return c.ru.reduce((a,b)=>a+b,0)*1000; }
