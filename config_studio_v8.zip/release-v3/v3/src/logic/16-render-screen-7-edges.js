    /* Screen 7 edges */
    const edge=this.edgeById(S.edgeId); V.edge=edge; V.edgeTabs=this.edgeList().map(e=>Object.assign({name:e.name,onClick:()=>this.setState({edgeId:e.name})},edge.name===e.name?sel:unsel));
