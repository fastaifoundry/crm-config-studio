// ===== Authentication provision =====
// Prototype: mode 'local' with the dummy account below.
// Real studio: set mode to 'msal' and fill the msal block — nothing else changes. The login screen then shows only the
// "Sign in with your work account" button, login() calls Component.AUTH.signIn(), and the user chip reads the account.
// Wire signIn/acquireToken/signOut to @azure/msal-browser (PublicClientApplication, loginRedirect / acquireTokenSilent /
// logoutRedirect) — the same three calls the Vue port uses in src/auth/msal.js.
const AUTH = {
  mode: 'local',                                   // 'local' | 'msal'
  local: { users: { admin: { password: 'admin', name: 'Admin User', upn: 'admin@bank.example', roles: ['schema_owner', 'architect'], team: 'T-0001' } } },
  msal: {
    clientId: '00000000-0000-0000-0000-000000000000',
    tenantId: '00000000-0000-0000-0000-000000000000',
    authority: 'https://login.microsoftonline.com/<tenantId>',
    redirectUri: typeof location !== 'undefined' ? location.origin : '',
    scopes: ['api://crm-config-studio/.default'],
    // Replace these three with msal-browser calls; each must resolve to {name, upn, oid, roles, team} / a bearer token / void.
    signIn: async () => { throw new Error('AUTH.msal.signIn not wired: call PublicClientApplication.loginRedirect({scopes})'); },
    acquireToken: async () => { throw new Error('AUTH.msal.acquireToken not wired: call acquireTokenSilent({scopes, account})'); },
    signOut: async () => { throw new Error('AUTH.msal.signOut not wired: call logoutRedirect()'); },
  },
  // Map the ID-token claims to the studio user. Adjust claim names to your app registration.
  fromClaims: (c) => ({ name: c.name, upn: c.preferred_username || c.upn, oid: c.oid, roles: c.roles || [], team: (c.groups || []).find((g) => /^T-/.test(g)) || '' }),
};
