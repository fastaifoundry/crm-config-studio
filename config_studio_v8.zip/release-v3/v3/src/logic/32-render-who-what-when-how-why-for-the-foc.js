    /* who-what-when-how-why for the focus */
    const auditFor=id=>Component.AUDIT_SEED.concat(S.audit||[]).filter(r=>(r.target||'').includes(id));
    const w5=[]; if(focusObj){ const fo=focusObj; const cons=this.consumersOf(fo.api); const last=auditFor(fo.api)[0]; const dep=Component.DEPLOYED;
      w5.push({k:'What',v:`${fo.kind} object · ${this.fieldsOf(fo).length} fields${fo.extends?' · extends '+fo.extends:''}`});
      w5.push({k:'Who',v:`${fo.owner} owns it · ${cons.length} consumer${cons.length===1?'':'s'} read it · last change ${last?last.who+', '+last.at:'—'}`});
      w5.push({k:'When',v:`changed ${fo.changed} · prod runs ${dep.prod.release} · ${S.env} runs ${dep[S.env].ref}${(this.vsMain(`objects/${fo.api}.yaml`).length)?' · differs from main on your branch':''}`});
      w5.push({k:'How',v:`${fo.container} container · _type "${fo.api}" · partition ${fo.kind==='party-scoped'||fo.kind==='root'?'/party_id':'/_global'} · ${this.fieldsOf(fo).filter(f=>f.flt).length} indexed paths`});
      w5.push({k:'Why',v:fo.desc});
      w5.push({k:'Usage',v:`${this.fmt(cons.reduce((a,c)=>a+this.ruTotal(c),0))} RU · 7 days · ${cons.length} consumers`});
    } else if(focusCons){ const c=focusCons; const last=auditFor(c.name.split('.')[1]||c.name)[0];
      w5.push({k:'What',v:`${c.type==='ui'?'screen API':'integration API'} · ${c.fnApp||'—'} · ${c.grants.length} grants · ${(c.routes||[]).length} routes`});
      w5.push({k:'Who',v:`${c.owner} owns it · runs as ${c.clientId} · last change ${last?last.who+', '+last.at:'—'}`});
      w5.push({k:'When',v:`last seen ${c.lastSeen} · ${c.status}`});
      w5.push({k:'How',v:`reads ${c.grants.filter(g=>g.kind==='object').map(g=>g.target).join(', ')} · ${c.grants.flatMap(g=>g.queries).length} named queries`});
      w5.push({k:'Why',v:c.desc||'—'});
      w5.push({k:'Usage',v:`${this.fmt(this.ruTotal(c))} RU · 7 days${c.budget?' · budget '+this.fmt(c.budget*7):''}`});
    }
    V.lgW5=w5; V.lgLegend=[['object','Object'],['consumer','Consumer / route'],['view','View'],['edge','Edge'],['picklist','Picklist / master'],['graph','Graph query']].map(([k,label])=>Object.assign({label},nodeChip(k)));
