#!/usr/bin/env bash
# collect-containers.sh — gathers Cosmos DB container facts for the CRM Config Studio "Containers" screen (Catalog mode).
#
# Output: one JSON document (stdout or --out <file>) shaped for the screen:
#   { "as_of": "...", "account": "...", "databases": [...], "containers": [ { name, database, purpose, partition_key, throughput, ttl,
#     indexing: { mode, included, excluded, composite }, size_gb, document_count, ru_24h,
#     discriminator: "_type", documents_by_object: [ { object, docs } ], top_partitions: [ { key, size_gb, pct } ] } ] }
#
# Requirements: az CLI ≥ 2.60 (cosmosdb + monitor extensions), jq. Logged in with a reader role on the account and
# "Monitoring Reader" on the resource group. Nothing here writes to Azure.
#
# Usage:
#   ./collect-containers.sh -a crm-prod-rg/crm-prod-cosmos:crm,crm-uniques -a crm-prod-rg/crm-activity-cosmos:activity [--out containers.json]
#   -a may repeat: <resource-group>/<account>:<db1,db2,…>. Containers are discovered per database and tagged with account + database.
#   Auth: one user-assigned managed identity with Cosmos DB Built-in Data Reader on every account (az login --identity -u <client id>).
#   --tag crm-data=true   discovers every Cosmos DB account in the subscription carrying the tag (preferred when there are many);
#                         all databases in each discovered account are scanned. Combine with -a to add untagged accounts.
#   Legacy form -g <rg> -a <account> -d <dbs> still works for a single account.
#
#   Discovery command used for --tag:
#     az cosmosdb list --query "[?tags.\"crm-data\"=='true'].{name:name,rg:resourceGroup}" -o json
#     az cosmosdb sql database list -g <rg> -a <account> --query '[].name' -o tsv
#   ./collect-containers.sh ... --purpose-file storage/purposes.yaml   # optional: purpose text per container from the repo

set -euo pipefail

RG="" ACCOUNT="" DB="" CONTAINERS="" OUT="" PURPOSES=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    -g|--resource-group) RG="$2"; shift 2;;
    -a|--account)        ACCOUNT="$2"; shift 2;;
    -d|--database)       DB="$2"; shift 2;;
    -c|--containers)     CONTAINERS="$2"; shift 2;;
    --out)               OUT="$2"; shift 2;;
    --purpose-file)      PURPOSES="$2"; shift 2;;
    -h|--help) sed -n '2,16p' "$0"; exit 0;;
    *) echo "unknown arg $1" >&2; exit 2;;
  esac
done
[[ -z "$RG" || -z "$ACCOUNT" || -z "$DB" ]] && { echo "need -g, -a, -d" >&2; exit 2; }
IFS=',' read -ra DBS <<< "$DB"
command -v jq >/dev/null || { echo "jq is required" >&2; exit 2; }

SUB=$(az account show --query id -o tsv)
ACCOUNT_ID="/subscriptions/$SUB/resourceGroups/$RG/providers/Microsoft.DocumentDB/databaseAccounts/$ACCOUNT"
AS_OF=$(date -u +%Y-%m-%dT%H:%M:%SZ)
FROM=$(date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -v-24H +%Y-%m-%dT%H:%M:%SZ)

# 1. Which containers, per database. Default: everything in each database. Entries become "db/container".
PAIRS=""
for D in "${DBS[@]}"; do
  if [[ -z "$CONTAINERS" ]]; then NAMES_D=$(az cosmosdb sql container list -g "$RG" -a "$ACCOUNT" -d "$D" --query '[].name' -o tsv); else NAMES_D=$(echo "$CONTAINERS" | tr ',' '\n'); fi
  for N in $NAMES_D; do PAIRS="$PAIRS $D/$N"; done
done

# 2. Account-level: RU per container over the last 24 h (one call, then filtered per container).
#    Metric dimension CollectionName carries the container name.
RU_JSON=$(az monitor metrics list --resource "$ACCOUNT_ID" \
  --metric TotalRequestUnits --start-time "$FROM" --end-time "$AS_OF" \
  --interval PT1H --aggregation Total \
  --filter "DatabaseName eq '*' and CollectionName eq '*'" -o json)

# 3. Account-level: storage and document count per container (latest sample).
SIZE_JSON=$(az monitor metrics list --resource "$ACCOUNT_ID" \
  --metric DataUsage,IndexUsage,DocumentCount --start-time "$FROM" --end-time "$AS_OF" \
  --interval PT1H --aggregation Maximum \
  --filter "DatabaseName eq '*' and CollectionName eq '*'" -o json)

# 4. Per-partition size. PhysicalPartitionSizeInfo is per physical partition; the logical-partition breakdown
#    (needed for "top partitions") is not a Monitor metric — it comes from Partition Key Statistics in diagnostics.
#    If the account streams PartitionKeyStatistics to a Log Analytics workspace, set LAW_ID to enable it.
LAW_ID="${LAW_ID:-}"

metric_total() { # $1 json, $2 metric, $3 container, $4 agg field  (uses $DB from the loop)
  echo "$1" | jq -r --arg m "$2" --arg c "$3" --arg f "$4" --arg d "$DB" '
    [.[] | select(.name.value==$m) | .timeseries[] | select(any(.metadatavalues[]; .name.value=="collectionname" and (.value|ascii_downcase)==($c|ascii_downcase)) and any(.metadatavalues[]; .name.value=="databasename" and (.value|ascii_downcase)==($d|ascii_downcase)))
      | .data[] | .[$f] // 0] | add // 0'; }
metric_last() { # latest non-null sample
  echo "$1" | jq -r --arg m "$2" --arg c "$3" --arg f "$4" --arg d "$DB" '
    [.[] | select(.name.value==$m) | .timeseries[] | select(any(.metadatavalues[]; .name.value=="collectionname" and (.value|ascii_downcase)==($c|ascii_downcase)) and any(.metadatavalues[]; .name.value=="databasename" and (.value|ascii_downcase)==($d|ascii_downcase)))
      | .data[] | .[$f] | select(.!=null)] | last // 0'; }

purpose_for() { # optional YAML "name: purpose" lines
  [[ -n "$PURPOSES" && -f "$PURPOSES" ]] && grep -E "^$1:" "$PURPOSES" | sed -E 's/^[^:]+:[[:space:]]*//' | tr -d '"' || true; }

RESULT='[]'
for PAIR in $PAIRS; do
  DB="${PAIR%%/*}"; C="${PAIR##*/}"
  echo "· $DB/$C" >&2

  # 5. Container config: partition key, TTL, indexing policy (paths + composite indexes).
  CFG=$(az cosmosdb sql container show -g "$RG" -a "$ACCOUNT" -d "$DB" -n "$C" -o json)
  PK=$(echo "$CFG" | jq -r '.resource.partitionKey.paths | join(", ")')
  TTL=$(echo "$CFG" | jq -r 'if .resource.defaultTtl==null then "none" elif .resource.defaultTtl==-1 then "per item" else "\(.resource.defaultTtl/86400|floor) days" end')
  INDEXING=$(echo "$CFG" | jq '{
    mode: .resource.indexingPolicy.indexingMode,
    included: [.resource.indexingPolicy.includedPaths[]?.path],
    excluded: [.resource.indexingPolicy.excludedPaths[]?.path],
    composite: [.resource.indexingPolicy.compositeIndexes[]? | map("\(.path) \(.order)") | join(", ")] }')

  # 6. Throughput: manual RU/s or autoscale max. Falls back to "shared (database)" when the container has none of its own.
  THR=$(az cosmosdb sql container throughput show -g "$RG" -a "$ACCOUNT" -d "$DB" -n "$C" -o json 2>/dev/null || echo '{}')
  THROUGHPUT=$(echo "$THR" | jq -r '
    if .resource.autoscaleSettings.maxThroughput then "autoscale \((.resource.autoscaleSettings.maxThroughput/10)|floor)–\(.resource.autoscaleSettings.maxThroughput) RU/s"
    elif .resource.throughput then "manual \(.resource.throughput) RU/s"
    else "shared (database)" end')

  # 7. Metrics for this container.
  RU24=$(metric_total "$RU_JSON" TotalRequestUnits "$C" total)
  DATA=$(metric_last "$SIZE_JSON" DataUsage "$C" maximum)
  INDEX=$(metric_last "$SIZE_JSON" IndexUsage "$C" maximum)
  DOCS=$(metric_last "$SIZE_JSON" DocumentCount "$C" maximum)
  SIZE_GB=$(jq -n --argjson d "$DATA" --argjson i "$INDEX" '(($d+$i)/1073741824*10|round)/10')

  # 8. Documents per object. Containers hold many objects; each document carries its object name in _type.
  #    One aggregate query per container (cheap: served by the /_type index path). Add the path to includedPaths if excluded.
  BY_TYPE=$(az cosmosdb sql container query -g "$RG" -a "$ACCOUNT" -d "$DB" -n "$C" \
      --query-text "SELECT c._type AS type, COUNT(1) AS docs FROM c GROUP BY c._type" -o json 2>/dev/null \
    | jq '[.[] | {object: .type, docs: .docs}] | sort_by(-.docs)' || echo '[]')
  # Fallback if the CLI lacks the query subcommand: run the same SQL in Data Explorer, or via the SDK:
  #   for t in $(yq '.objects[] | select(.container=="'$C'") | .api_name' storage/objects.index.yaml); do
  #     az cosmosdb sql container query ... --query-text "SELECT VALUE COUNT(1) FROM c WHERE c._type='$t'"; done

  # 9. Top logical partitions (optional, needs Log Analytics with PartitionKeyStatistics enabled).
  TOP='[]'
  if [[ -n "$LAW_ID" ]]; then
    TOP=$(az monitor log-analytics query -w "$LAW_ID" --analytics-query "
      CDBPartitionKeyStatistics
      | where DatabaseName == '$DB' and CollectionName == '$C'
      | summarize SizeKb = max(SizeKb) by PartitionKey
      | top 5 by SizeKb desc" -o json 2>/dev/null \
      | jq --argjson total "$DATA" '[.[] | {key: .PartitionKey, size_gb: ((.SizeKb*1024/1073741824*100|round)/100), pct: (if $total>0 then ((.SizeKb*1024/$total*100)|round) else 0 end)}]' || echo '[]')
  fi

  ITEM=$(jq -n --arg name "$C" --arg db "$DB" --arg purpose "$(purpose_for "$C")" --arg pk "$PK" --arg thr "$THROUGHPUT" --arg ttl "$TTL" \
    --argjson indexing "$INDEXING" --argjson size "$SIZE_GB" --argjson docs "$DOCS" --argjson ru "$RU24" --argjson top "$TOP" --argjson by_type "$BY_TYPE" \
    '{name:$name, database:$db, purpose:$purpose, partition_key:$pk, throughput:$thr, ttl:$ttl, indexing:$indexing, size_gb:$size, document_count:$docs, ru_24h:$ru, discriminator:"_type", documents_by_object:$by_type, top_partitions:$top}')
  RESULT=$(echo "$RESULT" | jq --argjson it "$ITEM" '. + [$it]')
done

DOC=$(jq -n --arg as_of "$AS_OF" --arg account "$ACCOUNT" --argjson dbs "$(printf '%s\n' "${DBS[@]}" | jq -R . | jq -s .)" --argjson containers "$RESULT" \
  '{as_of:$as_of, account:$account, databases:$dbs, containers:$containers}')

if [[ -n "$OUT" ]]; then echo "$DOC" > "$OUT"; echo "wrote $OUT" >&2; else echo "$DOC"; fi

# ---------------------------------------------------------------------------------------------------------------
# Notes
# • Run every 15 min from the same job that syncs consumer RU; the screen shows `as_of`.
# • Design mode does not call this. It reads storage/<container>.yaml from the schema repo; drift between that file
#   and steps 5–6 above is what the "Storage" tab on an object should flag.
# • Metric names differ by API kind; these are for the SQL (NoSQL) API. For Mongo API use MongoRequests / DataUsage.
# • az monitor returns UTC; the screen renders local time.
# • If the account has more than ~20 containers, page the metric calls by CollectionName to stay under the
#   dimension-cardinality limit.
